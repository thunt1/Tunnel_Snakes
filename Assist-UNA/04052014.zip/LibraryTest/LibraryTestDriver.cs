﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LibraryTest;

/**************************************************************************************************
* 
* Name: 
* 
* ================================================================================================
* 
* Description: 
*              
*                       
* ================================================================================================        
* 
* Modification History
* --------------------
* 04/04/2014    CAF     Created test driver.
* 04/04/2014    JMB     Assisted.
*                      
*************************************************************************************************/

namespace LibraryTest
{
    class LibraryTestDriver
    {
        const int MAIN_MEMORY_SIZE = 256;
        /* 
            * For testing purposes, we've decided to make the memory portion of this driver public
            * to reflect that the memory will be made public as part of the "processing" portion
            * of the back-end.
            */
        Memory mainMemory = new Memory(MAIN_MEMORY_SIZE);
        PSW progStatWord = new PSW();
        Register[] registers = new Register[16];
        LibraryTest library = new LibraryTest();

        void Main(string[] args)
        {
            uint locationCounter = 0;
            for (int i = 0; i < 16; i++)
                registers[i] = new Register();

        }

    }
}
