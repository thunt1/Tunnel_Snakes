﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LibraryTest;

/**************************************************************************************************
 * 
 * Name: LibraryTest
 * 
 * ================================================================================================
 * 
 * Description: 
 *                       
 * ================================================================================================        
 * 
 * Modification History
 * --------------------
 * 04/04/2014    CAF    Created class,
 *                       
 *************************************************************************************************/

namespace LibraryTest
{
    class LibraryTest
    {
        /* Private members. */

        /* Public methods. */

        /******************************************************************************************
         * 
         * Name:        SimulateInstruction
         * 
         * Author(s):   Chad Farley
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        public void SimulateInstruction(out int locationCounter, out Memory mainMemory)
        {
            switch(mainMemory.GetByteHex(locationCounter))
            {
                /* A - Add */
                case "5A": 
                    break;
                /* AP - Add Packed */
                case "FA":
                    break;
                /* AR - Add Register */
                case "1A":
                    break;
                /* BAL - Branch and Link */
                case "":
                    break;
                /* BALR - Branch and Link Register */
                case "":
                    break;
                /* BC - Branch on Condition */
                case "":
                    break;
                /* BCR - Branch on Condition Register */
                case "":
                    break;
                /* BCT - Branch on Count */
                case "":
                    break;
                /* BCTR - Branch on Count Register */
                case "":
                    break;
                /* BXH - Branch on Index High */
                case "":
                    break;
                /* BXLE - Branch on Index Low or Equal */
                case "":
                    break;
                /* C - Compare */
                case "":
                    break;
                /* CLC - Compare Logical Characters */
                case "":
                    break;
                /* CLI - Compare Logical Immediate */
                case "":
                    break;
                /* CP - Compare Packed */
                case "":
                    break;
                /* CR - Compare Register */
                case "":
                    break;
                /* D - Divide */
                case "":
                    break;
                /* DP - Divide Packed */
                case "":
                    break;
                /* DR - Divide Register */
                case "":
                    break;
                /* ED - Edit */
                case "":
                    break;
                /* EDMK - Edit and Mark */
                case "":
                    break;
                /* L - Load */
                case "":
                    break;
                /* LA - Load Address */
                case "":
                    break;
                /* LM - Load Multiple */
                case "":
                    break;
                /* LR - Load Register */
                case "":
                    break;
                /* M - Multiply */
                case "":
                    break;
                /* MP - Multiply Packed */
                case "":
                    break;
                /* MR - Multiply Register */
                case "":
                    break;
                /* MVC - Move Characters */
                case "":
                    break;
                /* MVI - Move Immediate */
                case "":
                    break;
                /* N - Bitwise AND */
                case "":
                    break;
                /* NR - Bitwise AND Register */
                case "":
                    break;
                /* O - Bitwise OR */
                case "":
                    break;
                /* OR - Bitwise OR Register */
                case "":
                    break;
                /* PACK - Pack */
                case "":
                    break;
                /* S - Subtract */
                case "":
                    break;
                /* SP - Subtract Packed */
                case "":
                    break;
                /* SR - Subtract Register */
                case "":
                    break;
                /* ST - Store */
                case "":
                    break;
                /* UNPK - Unpack */
                case "":
                    break;
                /* XDECI - Convert Input to Decimal*/
                case "":
                    break;
                /* XDECO - Convert Output to Decimal */
                case "":
                    break;
                /* XPRNT/XREAD */
                case "":
                    /* XPRNT - Print Output */
                    if(mainMemory.GetByteHex(locationCounter+1)=="20")
                    {

                    }
                    /* XREAD - Read Input */
                    else if (mainMemory.GetByteHex(locationCounter = 1) == "00")
                    {

                    }
                    /* ERROR */
                    else
                    {

                    }
                    break;
                /* ZAP - Zero, Add Packed */
                case "":
                    break;
                /* ERROR */
                default:
                    break;
            };
        }

        /* Protected methods. */


        /* Private methods. */
    }
}
