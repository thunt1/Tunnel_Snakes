﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**************************************************************************************************
* 
* Name: 
* 
* ================================================================================================
* 
* Description: 
*              
*                       
* ================================================================================================        
* 
* Modification History
* --------------------
* MM/DD/YYYY    <initials>  Description of changes.
*                      
*************************************************************************************************/

namespace Processing.Example
{

    class Template
    {

        /* Constants. */

        /* Public members. */

        /* Protected members. */

        /* Private members. */


        /* Public methods. */

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/


        /* Protected methods. */


        /* Private methods. */


    }

}
