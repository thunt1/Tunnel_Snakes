﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LibraryTest;

/**************************************************************************************************
* 
* Name: 
* 
* ================================================================================================
* 
* Description: 
*              
*                       
* ================================================================================================        
* 
* Modification History
* --------------------
* 04/04/2014    CAF     Created test driver.
* 04/04/2014    JMB     Assisted.
*                      
*************************************************************************************************/

namespace LibraryTest
{
    class LibraryTestDriver
    {
        const int MAIN_MEMORY_SIZE = 256;
        /* 
            * For testing purposes, we've decided to make the memory portion of this driver public
            * to reflect that the memory will be made public as part of the "processing" portion
            * of the back-end.
            */
        

        static void Main(string[] args)
        {

            Memory mainMemory = new Memory(MAIN_MEMORY_SIZE);
            PSW progStatWord = new PSW();
            Register[] registers = new Register[16];
            LibraryTest library = new LibraryTest(mainMemory, registers, progStatWord);

            uint locationCounter = 0;
            for (int i = 0; i < 16; i++)
                registers[i] = new Register();

            string[] vals = { "F0", "32" };
            string[] vals2 = {"00", "00", "01", "32"};
            string[] vals3 = { "00", "01", "23", "05" };
            string[] vals4 = { "5A", "3F", "E0", "32" };

            mainMemory.SetBytes(0, vals);
            registers[15].SetBytes(0, vals2); // index reg
            registers[14].SetBytes(0, vals3); // base reg
            
            Console.WriteLine("DB Address in hex: {0}", library.DetermineAddressDB(0).ToString("X"));

            mainMemory.SetBytes(0, vals4);
            Console.WriteLine("DXB Address in hex: {0}", library.DetermineAddressDXB(1).ToString("X"));

            Console.ReadLine();


        }

    }
}
