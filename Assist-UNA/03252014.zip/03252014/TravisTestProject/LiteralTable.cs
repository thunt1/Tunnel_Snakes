﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TravisTestProject
{
    class LiteralTable : Table
    {
        /* Constants. */
        private const int MAX_LITERALS = 50;
        private const int MAX_SIZE = 101;

        /* Private members. */
        private Hashtable literalTable;
        private int numLiterals;


        /* Public methods. */

        public LiteralTable()
        {
            literalTable = new Hashtable(MAX_SIZE);
            numLiterals = 0;
        }

        override public bool isTableFull()
        {
            return (literalTable.Count == MAX_SIZE);
        }

        public bool isLiteral(string key)
        {
            return literalTable.ContainsKey(key);
        }

        public bool isLiteralFull()
        {
            return (literalTable.Count == MAX_LITERALS);
        }

        override public string GetAddress(string key)
        {
            return (string)literalTable[key];
        }

        public void Hash(string literal, string location)
        {
            literalTable.Add(literal, location);
            numLiterals++;
        }

        public void PrintTable()
        {
            Console.WriteLine("------------------------");
            Console.WriteLine("|     Literal Table    |");
            Console.WriteLine("| Literal   | Address  |");
            Console.WriteLine("|----------------------|");

            foreach (var key in literalTable.Keys)
                Console.WriteLine(String.Format("| {0} | {1} ",key,literalTable[key]));

            Console.WriteLine("------------------------");
        }
    }
}


