﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TravisTestProject
{
    class SymbolTable : Table
    {
        /* Constants. */
        private const int MAX_SYMBOLS = 100;
        private const int MAX_SIZE = 211;

        /* Private members. */
        private Hashtable symbolTable;
        private int numSymbols;


        /* Public methods. */

        public SymbolTable()
        {
            symbolTable = new Hashtable(MAX_SIZE);
            numSymbols = 0;
        }

        override public bool isTableFull()
        {
            return (symbolTable.Count == MAX_SIZE);
        }

        public bool isSymbol(string key)
        {
            return symbolTable.ContainsKey(key);
        }

        public bool isSymbolFull()
        {
            return (symbolTable.Count == MAX_SYMBOLS);
        }

        override public string GetAddress(string key)
        {
            return (string)symbolTable[key];
        }

        public void Hash(string symbol, string location)
        {
            symbolTable.Add(symbol, location);
            numSymbols++;
        }

        public void PrintTable()
        {
            Console.WriteLine("-----------------------");
            Console.WriteLine("|     Symbol Table    |");
            Console.WriteLine("| Symbol   | Address  |");
            Console.WriteLine("|---------------------|");

            foreach (var key in symbolTable.Keys)
                Console.WriteLine(String.Format("| {0,-8} | {1} |", key, symbolTable[key]));

            Console.WriteLine("-----------------------");
        }
    }
}
