﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LibraryTest;

 /**************************************************************************************************
 * 
 * Name: 
 * 
 * ================================================================================================
 * 
 * Description: 
 *              
 *                       
 * ================================================================================================        
 * 
 * Modification History
 * --------------------
 * 04/04/2014   CAF     Created test driver.
 * 04/04/2014   JMB     Assisted.
 * 04/07/2014   JMB     Added method to test the DB and DXB calculation methods.
 *                         CONCERN: In DXB, when X is 0, we are supposed to use the literal value
 *                        zero, not the contents of Register 0. Right? What about with DB?
 * 04/08/2014   CAF     Assisted JMB with general maintenance and testing conditions.
 * 04/08/2014   JMB     Maintained code and conducted testing.
 * 04/10/2014   CAF     Updated code to reflect function changes.
 * 04/11/2014   JMB     Removed unnecessary comments.
 * 04/13/2014   JMB     Removed more unnecessary comments.
 *                    
 *************************************************************************************************/

namespace LibraryTest
{
    class LibraryTestDriver
    {
        /* 
         * For testing purposes, we've decided to make the memory portion of this driver public
         * to reflect that the memory will be made public as part of the "processing" portion
         * of the back-end.
         */
        const uint MAIN_MEMORY_SIZE = 256;
        const uint NUM_REGISTERS = 16;

        static void Main(string[] args)
        {
            Memory mainMemory = new Memory(MAIN_MEMORY_SIZE);
            PSW progStatWord = new PSW();
            Register[] registers = new Register[NUM_REGISTERS];
            LibraryTest library = new LibraryTest(mainMemory, registers, progStatWord);
            uint locationCounter = 0;

            InitializeMemory(ref mainMemory);
            InitializeRegisters(ref registers);

            locationCounter = 40;
            progStatWord.SetCondCode(1);

            library.SimulateInstruction(ref locationCounter);

            Console.ReadLine();
        }

        /******************************************************************************************
         * 
         * Name:        InitializeMemory 
         * 
         * Author(s):   Michael Beaver     
         *              
         * Input:       mainMemory is a Memory object.
         * Return:      N/A
         * Description: This method will initialize the contents of mainMemory to a series of bytes
         *              (randomly generated) meant to simulate object code.
         *              
         *****************************************************************************************/
        static void InitializeMemory(ref Memory mainMemory)
        {
            string[] memoryData = {
                                    "40", "20", "6B", "20", "20", "20", "6B", "20", "21", "20", 
                                    "6B", "20", "20", "60", "41", "40", "00", "14", "18", "34", 
                                    "00", "00", "00", "05", "6C", "30", "C0", "6B", "58", "D0", 
                                    "C0", "26", "98", "EC", "D0", "0C", "07", "FE", "F5", "F5", 
                                    "DF", "0D", "00", "00", "00", "14", "F5", "F5", "F5", "F5", 
                                    "F5", "F5", "FF", "FF", "FF", "FD", "F5", "F5", "F5", "F5", 
                                    "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", 
                                    "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", 
                                    "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", 
                                    "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", 
                                    "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", 
                                    "40", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", 
                                    "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", 
                                    "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", 
                                    "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", 
                                    "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", 
                                    "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", 
                                    "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", 
                                    "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", 
                                    "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", 
                                    "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", 
                                    "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", 
                                    "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", 
                                    "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", 
                                    "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", 
                                    "F5", "F5", "F5", "F5", "F5", "F5"
                                   };

            /* Set each byte in memory. */
            for (uint i = 0; i < MAIN_MEMORY_SIZE; i++)
                mainMemory.SetByte(i, memoryData[i]);
        }

        /******************************************************************************************
         * 
         * Name:        InitializeRegisters
         * 
         * Author(s):   Michael Beaver     
         *              
         * Input:       registers is an array of Register objects.
         * Return:      N/A
         * Description: This method will initialize each Register object to a randomly generated
         *              value (in bytes). These values are meant to mimic actual register contents.
         *              
         *****************************************************************************************/
        static void InitializeRegisters(ref Register[] registers)
        {
            string[] registerContents = {"00", "00", "00", "00",    /* 0. */
                                         "00", "00", "01", "01",    /* 1. */
                                         "00", "00", "00", "0A",    /* 2. */
                                         "00", "00", "00", "0A",    /* 3. */
                                         "00", "00", "00", "01",    /* 4. */
                                         "FF", "FF", "FF", "FD",    /* 5. */
                                         "00", "00", "03", "AF",    /* 6. */
                                         "00", "00", "00", "FF",    /* 7. */
                                         "00", "00", "00", "04",    /* 8. */
                                         "00", "00", "00", "16",    /* 9. */
                                         "00", "00", "00", "FD",    /* A. */
                                         "00", "00", "00", "00",    /* B. */
                                         "00", "00", "00", "06",    /* C. */
                                         "00", "00", "00", "00",    /* D. */
                                         "00", "00", "00", "1F",    /* E. */
                                         "00", "00", "00", "1C"};   /* F. */
            uint j = 0;

            for (uint i = 0; i < NUM_REGISTERS; i++)
            {
                registers[i] = new Register();

                /* Set each byte. */
                registers[i].SetByte(0, registerContents[j]);
                registers[i].SetByte(1, registerContents[j + 1]);
                registers[i].SetByte(2, registerContents[j + 2]);
                registers[i].SetByte(3, registerContents[j + 3]);

                j += 4;
            }
                
        }

        /******************************************************************************************
         * 
         * Name:        TestAddressDB
         * 
         * Author(s):   Michael Beaver     
         *              
         * Input:       mainMemory is a Memory object, and library is a LibraryTest object.
         * Return:      N/A
         * Description: This method will test the DetermineAddressDB method of the LibraryTest
         *              class. All data used to calculate the address is displayed to the Console.
         *              
         *****************************************************************************************/
        static void TestAddressDB(ref Memory mainMemory, ref LibraryTest library)
        {
            uint address;

            Console.WriteLine("================================================================");
            Console.WriteLine("                 Testing DB Address Calculation                 ");
            Console.WriteLine("================================================================");

            Console.WriteLine("Object Code Address (uint) in Memory (will get 2 bytes): ");
            address = Convert.ToUInt32(Console.ReadLine());

            /* Display results. */
            //Console.WriteLine("Bytes: {0}", 
            //    mainMemory.GetBytesString(address, address + 1));
            //Console.WriteLine("\nDB Address: {0}", 
            //    library.DetermineAddressDB(address).ToString("X"));
        }

        /******************************************************************************************
         * 
         * Name:        TestAddressDXB
         * 
         * Author(s):   Michael Beaver     
         *              
         * Input:       mainMemory is a Memory object, and library is a LibraryTest object.
         * Return:      N/A
         * Description: This method will test the DetermineAddressDXB method of the LibraryTest
         *              class. All data used to calculate the address is displayed to the Console.
         *              
         *****************************************************************************************/
        static void TestAddressDXB(ref Memory mainMemory,  ref LibraryTest library)
        {
            uint address;

            Console.WriteLine("================================================================");
            Console.WriteLine("                 Testing DXB Address Calculation                ");
            Console.WriteLine("================================================================");

            Console.WriteLine("Object Code Address (uint) in Memory (will get 3 bytes): ");
            address = Convert.ToUInt32(Console.ReadLine());

            /* Display the results. */
            //Console.WriteLine("Bytes: {0}", 
            //    mainMemory.GetBytesString(address, address + 2));
            //Console.WriteLine("\nDXB Address: {0}", 
            //    library.DetermineAddressDXB(address).ToString("X"));
        }

    }

}
