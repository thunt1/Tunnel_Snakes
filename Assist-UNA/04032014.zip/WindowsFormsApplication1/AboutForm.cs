﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.IO;
using System.Diagnostics;


/**************************************************************************************************
 * 
 * Name: AboutForm class
 * 
 * ================================================================================================
 * 
 * Description: This class is the about form part of the main GUI. 
 *                            
 * ================================================================================================
 * 
 * Modification History
 * --------------------
 * 03/09/2014   ACA     Original version.
 * 03/17/2014   THH     Changed the start location to be center screen.
 *                      Corrected some commenting format issues.
 * 03/28/2014   ACA     Updated method names to standards.
 *  
 **************************************************************************************************/
namespace Assist_UNA
{
    public partial class AboutForm : Form
    {
       
        /* member */
        List<KeyEventArgs> key = new List<KeyEventArgs>();

        /* Public methods. */

        /******************************************************************************************
         * 
         * Name:        OptionsForm
         * 
         * Author(s):   Drew Aaron
         *              
         * Input:       N/A
         * Return:      N/A
         * Description: This method will initialize the about form.
         *  
         ******************************************************************************************/
        public AboutForm()
        {
            InitializeComponent();
        }


        /* Private Methods */

        /******************************************************************************************
         * 
         * Name:        BtnAboutCloseClick
         * 
         * Author(s):   Drew Aaron
         *              
         * Input:       User click event
         * Return:      N/A
         * Description: Will close the about form.
         *  
         ******************************************************************************************/
        private void BtnAboutCloseClick(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBox1_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Up || e.KeyData == Keys.Down ||
                e.KeyData == Keys.Left || e.KeyData == Keys.Right ||
                e.KeyData == Keys.A || e.KeyData == Keys.B)
                key.Add(e);

            if (key.Count() == 10)
                TunnelSnakes();

            if (!textBox1.Focused)
                textBox1.Focus();
        }

        private void AboutForm_Load(object sender, EventArgs e)
        {
            textBox1.Focus();
        }

        private void TunnelSnakes()
        {
            if (key[0].KeyData != Keys.Up && key[1].KeyData != Keys.Up)
            {
                key.Clear();
                return;
            }
            else if (key[2].KeyData != Keys.Down && key[3].KeyData != Keys.Down)
            {
                key.Clear();
                return;
            }
            else if (key[4].KeyData != Keys.Left && key[5].KeyData != Keys.Right)
            {
                key.Clear();
                return;
            }
            else if (key[6].KeyData != Keys.Left && key[7].KeyData != Keys.Right)
            {
                key.Clear();
                return;
            }
            else if (key[8].KeyData != Keys.B || key[9].KeyData != Keys.A)
            {
                key.Clear();
                return;
            }

            byte[] data = Convert.FromBase64String("aHR0cHM6Ly93d3cueW91dHViZS5jb20vd2F0Y2g/dj1DVmg3bFZNVFFCbw==");
            string decodedString = Encoding.UTF8.GetString(data);

            Process.Start(decodedString);
            key.Clear();
        }


    }
}
