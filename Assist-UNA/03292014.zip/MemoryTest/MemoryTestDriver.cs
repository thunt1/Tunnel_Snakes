﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MemoryTest;

/**************************************************************************************************
* 
* Name: MemoryTestDriver
* 
* ================================================================================================
* 
* Description: This class contains the program for testing the correctness of the Data classes 
*              (Memory, Register, and PSW).
*                       
* ================================================================================================        
* 
* Modification History
* --------------------
* 03/28/2014    JMB  Created class, members, and methods.
*                      
*************************************************************************************************/

namespace MemoryTest
{
    class MemoryTestDriver
    {
        /* Public methods. */

        /******************************************************************************************
         * 
         * Name:        Main
         * 
         * Author(s):   Michael Beaver
         *                        
         * Input:       The args are command line parameters.
         * Return:      N/A
         * Description: This is the main driver method.
         * 
         *****************************************************************************************/
        static void Main(string[] args)
        {
            string menuSel;
            MemoryTest mt = new MemoryTest();
            PSWTest pt = new PSWTest();
            RegisterTest rt = new RegisterTest();
            int sel;
            string size;

            /* Get the memory size from the user. */
            Console.WriteLine("Memory size [256, 9999]: ");
            size = Console.ReadLine();

            /* Initialize the test objects. */
            mt.Initialize(Convert.ToInt32(size));
            pt.Initialize();
            rt.Initialize();

            /* Loop until the user quits. */
            do
            {
                /* Get the user's menu selection. */
                Console.Clear();
                menuSel = Menu();
                sel = Convert.ToInt32(menuSel);
                Console.Clear();

                /* Memory Testing. */
                if (sel > 0 && sel < 16)
                    MemoryTestHandler(sel, mt);

                /* Register Testing. */
                else if (sel > 15 && sel < 26)
                    RegisterTestHandler(sel, rt);

                /* PSW Testing. */
                else if (sel > 25 && sel < 37)
                    PSWTestHandler(sel, pt);

                Console.ReadLine();
            } while (menuSel != "37");
        }

        /******************************************************************************************
         * 
         * Name:        Menu
         * 
         * Author(s):   Michael Beaver
         *                        
         * Input:       N/A
         * Return:      The menu selection is a string.
         * Description: This method displays a menu and prompts the user of a selection.
         * 
         *****************************************************************************************/
        static string Menu()
        {
            string choice;

            Console.WriteLine("------------------------------------------------------------------");
            Console.WriteLine("                            Main Menu                             ");
            Console.WriteLine("------------------------------------------------------------------");

            Console.WriteLine("   Memory Testing    |   Register Testing   |      PSW Testing    ");
            Console.WriteLine("---------------------|----------------------|---------------------");
            Console.WriteLine("01) Display Contents | 16) Display Contents | 26) Display Contents");
            Console.WriteLine("02) Get Byte         | 17) Get Bytes        | 27) Get Bytes       ");
            Console.WriteLine("03) Get Bytes        | 18) Get Byte Hex     | 28) Get Bytes Int   ");
            Console.WriteLine("04) Get Byte Hex     | 19) Get Byte Int     | 29) Get Bytes String");
            Console.WriteLine("05) Get Byte Int     | 20) Get Bytes Int    | 30) Get CC Int      ");
            Console.WriteLine("06) Get Bytes Int    | 21) Get Bytes String | 31) Set Byte Int    ");
            Console.WriteLine("07) Get Bytes String | 22) Set Byte Int     | 32) Set Byte String ");
            Console.WriteLine("08) Get EBCDIC Chars | 23) Set Byte String  | 33) Set Ints Contig.");
            Console.WriteLine("09) Get Memory Size  | 24) Set Ints Contig. | 34) Set Strs Contig.");
            Console.WriteLine("10) Set Byte Int     | 25) Set Strs Contig. | 35) Set CC Int      ");
            Console.WriteLine("11) Set Byte String  |                      | 36) Set CC Bits     ");
            Console.WriteLine("12) Set Ints Contig. |                      |                     ");
            Console.WriteLine("13) Set Ints Noncon. |                      |                     ");
            Console.WriteLine("14) Set Strs Contig. |                      |                     ");
            Console.WriteLine("15) Set Strs Noncon. |                      |                     ");
            Console.WriteLine("---------------------|----------------------|---------------------");
            Console.WriteLine("                     |       37) Quit       |                     ");
            Console.WriteLine("---------------------|----------------------|---------------------");

            Console.WriteLine("Choice: ");
            choice = Console.ReadLine();

            return choice;
        }

        /******************************************************************************************
         * 
         * Name:        MemoryTestHandler
         * 
         * Author(s):   Michael Beaver
         *                        
         * Input:       Sel is an integer, and mt is a MemoryTest object.
         * Return:      N/A
         * Description: This method selects the appropriate MemoryTest test method given the user's
         *              menu selection ("sel").
         * 
         *****************************************************************************************/
        static void MemoryTestHandler(int sel, MemoryTest mt)
        {
            switch(sel)
            {
                /* Display Contents. */
                case 1:
                    {
                        mt.DisplayMemoryContents();
                        break;
                    }

                /* Get Byte. */
                case 2:
                    {
                        mt.GetByteTest();
                        break;
                    }

                /* Get Bytes. */
                case 3:
                    {
                        mt.GetBytesTest();
                        break;
                    }

                /* Get Byte Hex. */
                case 4:
                    {
                        mt.GetByteHexTest();
                        break;
                    }

                /* Get Byte Int. */
                case 5:
                    {
                        mt.GetByteIntTest();
                        break;
                    }

                /* Get Bytes Int. */
                case 6:
                    {
                        mt.GetBytesIntTest();
                        break;
                    }

                /* Get Bytes String. */
                case 7:
                    {
                        mt.GetBytesStringTest();
                        break;
                    }

                /* Get EBCDIC Chars. */
                case 8:
                    {
                        mt.GetEBCDICTest();
                        break;
                    }

                /* Get Memory Size. */
                case 9:
                    {
                        mt.GetMemorySizeTest();
                        break;
                    }

                /* Set Byte Int. */
                case 10:
                    {
                        mt.SetByteIntTest();
                        break;
                    }
                
                /* Set Byte String. */
                case 11:
                    {
                        mt.SetByteStringTest();
                        break;
                    }

                /* Set Ints Contiguous. */
                case 12:
                    {
                        mt.SetBytesContiguousIntsTest();
                        break;
                    }

                /* Set Ints Noncontiguous. */
                case 13:
                    {
                        mt.SetBytesNoncontiguousIntsTest();
                        break;
                    }

                /* Set Strings Contiguous. */
                case 14:
                    {
                        mt.SetBytesContiguousStringsTest();
                        break;
                    }

                /* Set Strings Noncontiguous. */
                case 15:
                    {
                        mt.SetBytesNoncontiguousStringsTest();
                        break;
                    }
            }
        }

        /******************************************************************************************
         * 
         * Name:        PSWTestHandler
         * 
         * Author(s):   Michael Beaver
         *                        
         * Input:       Sel is an integer, and pt is a PSWTest object.
         * Return:      N/A
         * Description: This method selects the appropriate PSWTest test method given the user's
         *              menu selection ("sel").
         * 
         *****************************************************************************************/
        static void PSWTestHandler(int sel, PSWTest pt)
        {
            switch(sel)
            {
                /* Display Contents. */
                case 26:
                    {
                        pt.DisplayPSWContents();
                        break;
                    }

                /* Get Bytes. */
                case 27:
                    {
                        pt.GetBytesTest();
                        break;
                    }

                /* Get Bytes Int. */
                case 28:
                    {
                        pt.GetBytesIntTest();
                        break;
                    }

                /* Get Bytes String. */
                case 29:
                    {
                        pt.GetBytesStringTest();
                        break;
                    }

                /* Get Condition Code Int. */
                case 30:
                    {
                        pt.GetCondCodeIntTest();
                        break;
                    }

                /* Set Byte Int. */
                case 31:
                    {
                        pt.SetByteIntTest();
                        break;
                    }

                /* Set Byte String. */
                case 32:
                    {
                        pt.SetByteStringTest();
                        break;
                    }
                
                /* Set Ints Contiguous. */
                case 33:
                    {
                        pt.SetBytesContiguousIntsTest();
                        break;
                    }

                /* Set Strings Contiguous. */
                case 34:
                    {
                        pt.SetBytesContiguousStringsTest();
                        break;
                    }

                /* Set Condition Code Int. */
                case 35:
                    {
                        pt.SetCondCodeIntTest();
                        break;
                    }

                /* Set Condition Code Bits. */
                case 36:
                    {
                        pt.SetCondCodeBitsTest();
                        break;
                    }
            }
        }

        /******************************************************************************************
         * 
         * Name:        RegisterTestHandler
         * 
         * Author(s):   Michael Beaver
         *                        
         * Input:       Sel is an integer, and rt is a RegisterTest object.
         * Return:      N/A
         * Description: This method selects the appropriate RegisterTest test method given the 
         *              user's menu selection ("sel").
         * 
         *****************************************************************************************/
        static void RegisterTestHandler(int sel, RegisterTest rt)
        {
            switch(sel)
            {
                /* Display Contents. */
                case 16:
                    {
                        rt.DisplayRegisterContents();
                        break;
                    }

                /* Get Bytes. */
                case 17:
                    {
                        rt.GetBytesTest();
                        break;
                    }

                /* Get Byte Hex. */
                case 18:
                    {
                        rt.GetByteHexTest();
                        break;
                    }

                /* Get Byte Int. */
                case 19:
                    {
                        rt.GetByteIntTest();
                        break;
                    }

                /* Get Bytes Int. */
                case 20:
                    {
                        rt.GetBytesIntTest();
                        break;
                    }

                /* Get Bytes String. */
                case 21:
                    {
                        rt.GetBytesStringTest();
                        break;
                    }

                /* Set Byte Int. */
                case 22:
                    {
                        rt.SetByteIntTest();
                        break;
                    }

                /* Set Byte String. */
                case 23:
                    {
                        rt.SetByteStringTest();
                        break;
                    }

                /* Set Ints Contiguous. */
                case 24:
                    {
                        rt.SetBytesContiguousIntsTest();
                        break;
                    }

                /* Set Strings Contiguous. */
                case 25:
                    {
                        rt.SetBytesContiguousStringsTest();
                        break;
                    }
            }
        }

    }

}
