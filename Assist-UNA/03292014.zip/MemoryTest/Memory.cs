﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**************************************************************************************************
* 
* Name: Memory
* 
* ================================================================================================
* 
* Description: This class represents the ASSIST/UNA's simulator's memory. The memory contents are
*              represented as an array of byte obejcts.            
*                       
* ================================================================================================        
* 
* Modification History
* --------------------
* 03/27/2014    JMB  Created class, members, and methods.
* 03/28/2014    JMB  Updated documentation for class and each method.
*                      
*************************************************************************************************/

namespace MemoryTest
{

    class Memory
    {
        /* Constants. */
        private const string DEFAULT_BYTE_VALUE = "F5";
        private const int MAX_MEMORY_SIZE = 9999;
        private const int MIN_MEMORY_SIZE = 256;


        /* Private members. */
        private byte[] memoryContents;
        private int memorySize;
       

        /* Public methods. */

        /******************************************************************************************
         * 
         * Name:        Memory
         * 
         * Author(s):   Michael Beaver
         *                        
         * Input:       N/A  
         * Return:      N/A   
         * Description: Default constructor creates and initializes an array of bytes of size
         *              MIN_MEMORY_SIZE.
         *              
         *****************************************************************************************/
        public Memory()
        {
            memorySize = MIN_MEMORY_SIZE;

            /* Create and initialize the actual memory contents array. */
            memoryContents = new byte[memorySize];
            InitializeMemoryContents();
        }

        /******************************************************************************************
         * 
         * Name:        Memory 
         * 
         * Author(s):   Michael Beaver        
         *              
         * Input:       The size is an integer.     
         * Return:      N/A  
         * Description: The overloaded constructor that allows the user to specify the size of the
         *              memory contents (the "size" parameter). The constructor will not use a size
         *              smaller than MIN_MEMORY_SIZE or larger than MAX_MEMORY_SIZE. The memory
         *              contents are created and initialized.
         *              
         *****************************************************************************************/
        public Memory(int size)
        {
            /* Check memory size bounds. */
            if (size < MIN_MEMORY_SIZE)
                memorySize = MIN_MEMORY_SIZE;

            else if (size > MAX_MEMORY_SIZE)
                memorySize = MAX_MEMORY_SIZE;

            else
                memorySize = size;

            /* Create and initialize the actual memory contents array. */
            memoryContents = new byte[memorySize];
            InitializeMemoryContents();
        }

        /******************************************************************************************
         * 
         * Name:        GetByte   
         * 
         * Author(s):   Michael Beaver 
         *                   
         * Input:       The index is an integer.      
         * Return:      The requested byte is a byte.
         * Description: This method will find in the memory contents a byte specified by location
         *              "index" and return it as a byte object.
         *                         
         *****************************************************************************************/
        public byte GetByte(int index)
        {
            byte result = new byte();

            /* Attempt to retrieve the byte value at the given location. */
            try
            {
                result = memoryContents[index];
            }
                 
            /* Index was out of bounds. */
            catch (IndexOutOfRangeException)
            {
                Console.WriteLine("Error: Index out of bounds!");
            }

            return result;
        }

        /******************************************************************************************
         * 
         * Name:        GetBytes     
         * 
         * Author(s):   Michael Beaver
         *                         
         * Input:       The start and end are integers.   
         * Return:      The requested bytes are returned as an array of byte objects.    
         * Description: This method will locate and return an array of requested byte objects. The
         *              range used is inclusive (so, [start, end]). If there is an error, the 
         *              return value will be null.
         *                      
         *****************************************************************************************/
        public byte[] GetBytes(int start, int end)
        {
            /* Do not use a negative range. */
            if (end < start)
                return null;
            
            /* Inclusive range. */
            byte[] result = new byte[end - start + 1];

            /* Attempt to copy the values. */
            try
            {
                int i = 0;
                int j = start;

                while (j <= end) 
                {
                    result[i] = memoryContents[j];

                    i++;
                    j++;
                }
            }

            /* Index was out of bounds. */
            catch (IndexOutOfRangeException)
            {
                Console.WriteLine("Error: Index out of bounds!");

                result = null;
            }

            return result;
        }

        /******************************************************************************************
         * 
         * Name:        GetByteHex     
         * 
         * Author(s):   Michael Beaver
         *                          
         * Input:       The index is an integer.    
         * Return:      The hexadecimal value is a string.  
         * Description: This method will return the hexadecimal representation as a string of a
         *              byte in memory, whose location is specified by "index." If there is an
         *              error, the returned result will be null.
         *                          
         *****************************************************************************************/
        public string GetByteHex(int index)
        {
            string result;

            /* Get the hexadecimal representation. */
            try
            {
                result = memoryContents[index].ToString("X").PadLeft(2, '0');
            }

            /* Index is out of bounds. */
            catch (IndexOutOfRangeException)
            {
                Console.WriteLine("Error: Index out of bounds!");

                result = null;
            }

            return result;
        }

        /******************************************************************************************
         * 
         * Name:        GetByteInt     
         * 
         * Author(s):   Michael Beaver
         *              
         * Input:       The index is an integer.   
         * Return:      The integer value of the byte is an integer.   
         * Description: This method will return the integer value of a byte in memory, whose 
         *              location is specified by "index." If there is an error, the returned
         *              result will be -1.
         *              
         *****************************************************************************************/
        public int GetByteInt(int index)
        {
            int result;

            /* Get the integer value. */
            try
            {
                result = memoryContents[index];
            }

            /* Index is out of bounds. */
            catch (IndexOutOfRangeException)
            {
                Console.WriteLine("Error: Index out of bounds!");

                result = -1;
            }

            return result;
        }

        /******************************************************************************************
         * 
         * Name:        GetBytesInt     
         * 
         * Author(s):   Michael Beaver 
         *                       
         * Input:       The start and end values are integers.      
         * Return:      The integer value of the bytes is an integer.  
         * Description: This method will return the integer value of a series of bytes in memory. 
         *              This method will take a sequence of bytes (inclusive, [start, end]) and
         *              calculate the value of that sequence of bytes. If there is an error,
         *              the returned result will be -1.
         *                 
         *****************************************************************************************/
        public int GetBytesInt(int start, int end)
        {
            string bytesString;
            int result;

            /* Get the sequence of bytes as a string. */
            bytesString = GetBytesString(start, end);

            /* The sequence of bytes does not exist, or an error occurred. */
            if (bytesString == null)
                result = -1;

            /* Actually calculate the integer value, if possible. */
            else
                result = Convert.ToInt32(bytesString, 16);

            return result;
        }

        /******************************************************************************************
         * 
         * Name:        GetBytesString     
         * 
         * Author(s):   Michael Beaver         
         *              
         * Input:       The start and end values are integers. 
         * Return:      The hexadecimal bytes are a string.  
         * Description: This method will return a string of bytes in hexadecimal representation. 
         *              The range is inclusive (so, [start, end]). If there is an error, the
         *              returned result will be null.
         *                     
         *****************************************************************************************/
        public string GetBytesString(int start, int end)
        {
            /* Do not use a negative range. */
            if (end < start)
                return null;

            string result = "";

            /* Create the hexadecimal string. */
            try
            {
                int i = 0;
                int j = start;

                while (j <= end)
                {
                    result += memoryContents[j].ToString("X").PadLeft(2, '0');

                    i++;
                    j++;
                }
            }

            /* Index was out of bounds. */
            catch (IndexOutOfRangeException)
            {
                Console.WriteLine("Error: Index out of bounds!");

                result = null;
            }

            return result;
        }

        /******************************************************************************************
         * 
         * Name:        GetEBCDIC      
         * 
         * Author(s):   Michael Beaver
         *                         
         * Input:       The start and end values are integers.   
         * Return:      The EBCDIC characters form a string.   
         * Description: This method will return the EBCDIC character representation of a sequence
         *              of bytes in memory. The range is inclusive (so, [start, end]). If an error
         *              occurs, the returned result will be null.
         *                     
         *****************************************************************************************/
        public string GetEBCDIC(int start, int end)
        {
            string result = "";
            
            /* Do not use a negative range. */
            if (end < start)
                return null;

            /* Form the EBCDIC character string. */
            try
            {
                for (int i = start; i <= end; i++)
                    result += ToEBCDIC(memoryContents[i].ToString());
            }

            /* An index was out of bounds. */
            catch (IndexOutOfRangeException)
            {
                Console.WriteLine("Error: Index out of bounds!");

                result = null;
            }

            return result;
        }

        /******************************************************************************************
         * 
         * Name:        GetMemorySize     
         * 
         * Author(s):   Michael Beaver
         *                      
         * Input:       N/A
         * Return:      The size of memory is an integer. 
         * Description: This method returns the size of memory.
         *              
         *****************************************************************************************/
        public int GetMemorySize()
        {
            return memorySize;
        }

        /******************************************************************************************
         * 
         * Name:        SetByte    
         * 
         * Author(s):   Michael Beaver      
         *              
         * Input:       The index and value are integers.   
         * Return:      The result is boolean.
         * Description: This method will attempt to set a byte in memory to a specified integer
         *              value. The specific byte's location is given by "index." If an error
         *              occurs, the returned result will be false. Otherwise the returned result
         *              will be true.          
         *              
         *****************************************************************************************/
        public bool SetByte(int index, int value)
        {
            bool result = false;

            /* Attempt to alter the byte's value. */
            try
            {
                memoryContents[index] = Byte.Parse(value.ToString());

                result = true;
            }

            /* The index was out of bounds. */
            catch (IndexOutOfRangeException)
            {
                Console.WriteLine("Error: Index out of bounds!");

                result = false;
            }

            return result;
        }

        /******************************************************************************************
         * 
         * Name:        SetByte     
         * 
         * Author(s):   Michael Beaver     
         *              
         * Input:       The index is an integer, and the value is a string.    
         * Return:      The result is boolean.
         * Description: This method will attempt to set a byte's value to a new hexadecimal 
         *              value specified by the user ("value"). The byte's location in memory is 
         *              given by "index." If an error occurs, the returned result will be false. 
         *              Otherwise, the returned result will be true.
         *                          
         *****************************************************************************************/
        public bool SetByte(int index, string value)
        {
            bool result = false;
            int tempVal;

            /* Attempt to set the byte to the new value. */
            try
            {
                tempVal = Convert.ToInt32(value, 16);
                memoryContents[index] = Byte.Parse(tempVal.ToString());

                result = true;
            }

            /* The value could not be converted. */
            catch (OverflowException)
            {
                Console.WriteLine("Error: Overflow during conversion!");

                result = false;
            }

            /* The index is out of bounds. */
            catch (IndexOutOfRangeException)
            {
                Console.WriteLine("Error: Index out of bounds!");

                result = false;
            }

            return result;
        }

        /******************************************************************************************
         * 
         * Name:        SetBytes    
         * 
         * Author(s):   Michael Beaver  
         *                         
         * Input:       The index is an integer, and values is an array of integers.   
         * Return:      The result is boolean.     
         * Description: This method will attempt to set a sequence of bytes (starting at "index")
         *              in memory to new values specified in the array "values." This method
         *              assumes the values are in sequence (i.e., contiguous). If an error occurs,
         *              the returned result will be false. Otherwise, the returned result will be
         *              true.
         *              
         *****************************************************************************************/
        public bool SetBytes(int index, int[] values)
        {
            bool result = false;

            /* Attempt to set the sequence of bytes. */
            try
            {
                /* The offset is used to traverse to the next contiguous byte in memory. */
                int offset = 0;

                foreach (int val in values)
                {
                    memoryContents[index + offset] = Byte.Parse(val.ToString());

                    offset++;
                }

                result = true;
            }

            /* An index was out of bounds. */
            catch (IndexOutOfRangeException)
            {
                Console.WriteLine("Error: Index out of bounds!");

                result = false;
            }

            return result;
        }

        /******************************************************************************************
         * 
         * Name:        SetBytes      
         * 
         * Author(s):   Michael Beaver 
         *                       
         * Input:       Indices and values are arrays of integers.    
         * Return:      The result is boolean. 
         * Description: This method will attempt to set bytes to new values specified in the
         *              "values" array. The locations of the bytes are given in the "indices"
         *              array. The bytes do NOT have to be contiguous in memory. The counts of the 
         *              "indices" and "values" arrays must be equal, or an error will result. If 
         *              an error occurs, the returned result will be false. Otherwise, the returned 
         *              result will be true.
         *                      
         *****************************************************************************************/
        public bool SetBytes(int[] indices, int[] values)
        {
            bool result = false;

            /* Check if the arrays are equal in size. */
            if (indices.Count() != values.Count())
                return false;

            /* Attempt to set the bytes to the new values. */
            try
            {
                int currentIndex;
                int i = 0;
                
                foreach (int val in values)
                {
                    currentIndex = indices[i];
                    memoryContents[currentIndex] = Byte.Parse(val.ToString());

                    i++;
                }

                result = true;
            }

            /* An index was out of bounds. */
            catch (IndexOutOfRangeException)
            {
                Console.WriteLine("Error: Index out of bounds!");

                result = false;
            }

            return result;
        }

        /******************************************************************************************
         * 
         * Name:        SetBytes     
         * 
         * Author(s):   Michael Beaver  
         *                         
         * Input:       The index is an integer, and values is an array of strings.
         * Return:      The result is boolean.
         * Description: This method will attempt to set a contiguous sequence of bytes in memory
         *              to new, user-specified values ("values"). The location of the first byte
         *              is given by "index." The values in "values" should be hexadecimal. If an
         *              error occurs, the returned result will be false. Otherwise, the returned
         *              result will be true.
         *                
         *****************************************************************************************/
        public bool SetBytes(int index, string[] values)
        {
            bool result = false;
            int tempVal;

            /* Attempt to set the bytes to the new values. */
            try
            {
                /* The offset is used to traverse to the next contiguous byte in memory. */
                int offset = 0;

                foreach (string val in values)
                {
                    tempVal = Convert.ToInt32(val, 16);
                    memoryContents[index + offset] = Byte.Parse(tempVal.ToString());

                    offset++;
                }

                result = true;
            }

            /* A value could not be converted. */
            catch (OverflowException)
            {
                Console.WriteLine("Error: Overflow during conversion!");

                result = false;
            }

            /* An index was out of bounds. */
            catch (IndexOutOfRangeException)
            {
                Console.WriteLine("Error: Index out of bounds!");

                result = false;
            }

            return result;
        }

        /******************************************************************************************
         * 
         * Name:        SetBytes    
         * 
         * Author(s):   Michael Beaver
         *                    
         * Input:       Indices is an array of integers, and values is an array of strings.   
         * Return:      The result is boolean.
         * Description: This method will attempt to set bytes to new values. The bytes' locations
         *              are given by the "indices" array and do not need to be contiguous. The new
         *              values are given by the "values" array and should be in hexadecimal. The
         *              sizes of the "indices" and "values" arrays must be equal. If an error
         *              occurs, the returned result will be false. Otherwise, the returned result
         *              will be true.
         *                   
         *****************************************************************************************/
        public bool SetBytes(int[] indices, string[] values)
        {
            bool result = false;
            int tempVal;

            /* Make sure the arrays are the same size. */
            if (indices.Count() != values.Count())
                return false;

            /* Attempt to set the bytes to their new values. */
            try
            {
                int i = 0;
                int currentIndex;

                foreach (string val in values)
                {
                    currentIndex = indices[i];
                    tempVal = Convert.ToInt32(val, 16);
                    memoryContents[currentIndex] = Byte.Parse(tempVal.ToString());

                    i++;
                }

                result = true;
            }

            /* A value could not be converted. */
            catch (OverflowException)
            {
                Console.WriteLine("Error: Overflow during conversion!");

                result = false;
            }

            /* An index was out of bounds. */
            catch (IndexOutOfRangeException)
            {
                Console.WriteLine("Error: Index out of bounds!");

                result = false;
            }

            return result;
        }


        /* Private methods. */

        /******************************************************************************************
         * 
         * Name:        InitializeMemoryContents    
         * 
         * Author(s):   Michael Beaver 
         *                       
         * Input:       N/A
         * Return:      N/A
         * Description: This method is used by the class constructor(s) to initialize the memory
         *              contents to the DEFAULT_BYTE_VALUE. The DEFAULT_BYTE_VALUE should be
         *              in hexadecimal.              
         *              
         *****************************************************************************************/
        private void InitializeMemoryContents()
        {
            string tempVal;

            /* Set all bytes in memory to the default byte value. */
            for (int i = 0; i < memorySize; i++)
            {
                tempVal = Convert.ToString(Convert.ToInt32(DEFAULT_BYTE_VALUE, 16));
                memoryContents[i] = Byte.Parse(tempVal);
            }
        }

        /******************************************************************************************
         * 
         * Name:        ToEBCDIC   
         * 
         * Author(s):   Michael Beaver
         *                  
         * Input:       The value is a string. 
         * Return:      The result is a string.
         * Description: This method will return the EBCDIC character representation for a given
         *              hexadecimal value ("value"). All non-printable, non-viewable characters
         *              are represented by periods (".") as is done in ASSIST/I. If an error
         *              occurs, the returned result will be a period. Otherwise, the returned
         *              result will be the converted character.
         *              
         *****************************************************************************************/
        private string ToEBCDIC(string value)
        {
                                   /* 0    1    2    3    4    5    6    7    8    9    A    B    C    D    E    F  */
            string[] EBCDICValues = {".", ".", ".", ".", ".", ".", ".", ".", ".", ".", ".", ".", ".", ".", ".", ".",  /* 0 */
                                     ".", ".", ".", ".", ".", ".", ".", ".", ".", ".", ".", ".", ".", ".", ".", ".",  /* 1 */
                                     ".", ".", ".", ".", ".", ".", ".", ".", ".", ".", ".", ".", ".", ".", ".", ".",  /* 2 */
                                     ".", ".", ".", ".", ".", ".", ".", ".", ".", ".", ".", ".", ".", ".", ".", ".",  /* 3 */
                                     " ", ".", ".", ".", ".", ".", ".", ".", ".", ".", "¢", ".", "<", "(", "+", "|",  /* 4 */
                                     ".", ".", ".", ".", ".", ".", ".", ".", ".", ".", "!", "$", "*", ")", ";", "¬",  /* 5 */
                                     "-", "/", ".", ".", ".", ".", ".", ".", ".", ".", "¦", ",", "%", "_", ">", "?",  /* 6 */
                                     ".", ".", ".", ".", ".", ".", ".", ".", ".", "`", ":", "#", "@", "'", "=", "\"", /* 7 */
                                     ".", "a", "b", "c", "d", "e", "f", "g", "h", "i", ".", ".", ".", ".", ".", ".",  /* 8 */
                                     ".", "j", "k", "l", "m", "n", "o", "p", "q", "r", ".", ".", ".", ".", ".", ".",  /* 9 */
                                     ".", "~", "s", "t", "u", "v", "w", "x", "y", "z", ".", ".", ".", ".", ".", ".",  /* A */
                                     ".", ".", ".", ".", ".", ".", ".", ".", ".", ".", ".", ".", ".", ".", ".", ".",  /* B */
                                     "{", "A", "B", "C", "D", "E", "F", "G", "H", "I", ".", ".", ".", ".", ".", ".",  /* C */
                                     "}", "J", "K", "L", "M", "N", "O", "P", "Q", "R", ".", ".", ".", ".", ".", ".",  /* D */
                                     "\\", ".", "S", "T", "U", "V", "W", "X", "Y", "Z", ".", ".", ".", ".", ".", ".", /* E */
                                     "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", ".", ".", ".", ".", ".", "."}; /* F */
            int index;
            string result;

            index = Convert.ToInt32(value);

            /* Convert to the EBCDIC character. */
            try
            {
                result = EBCDICValues[index];
            }

            /* The index was out of bounds. */
            catch (IndexOutOfRangeException)
            {
                Console.WriteLine("Error: Index out of bounds!");

                result = ".";
            }

            return result;
        }

    }

}

