﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**************************************************************************************************
* 
* Name: PSW
* 
* ================================================================================================
* 
* Description: This class represents a portion of the ASSIST/UNA's simulator's Program Status
*              Word (PSW). This class represents the location counter (instruction address) as an 
*              array of LOC_SIZE bytes and the condition code as COND_CODE_SIZE integers (0 or 1).
*                       
* ================================================================================================        
* 
* Modification History
* --------------------
* 03/28/2014    JMB  Created class, members, and methods.
* 03/28/2014    JMB  Updated all documentation.
*                      
*************************************************************************************************/

namespace SimulatorData
{

    class PSW
    {
        /* Constants. */
        private const int COND_CODE_SIZE = 2;
        private const string DEFAULT_BYTE_VALUE = "F4";
        private const int DEFAULT_COND_CODE_VALUE = 0;
        private const int LOC_SIZE = 3;
        private const int REGISTER_SIZE = 8;
        

        /* Private members. */
        private byte[] locContents;
        private int[] condCode;


        /* Public methods. */

        /******************************************************************************************
         * 
         * Name:        PSW
         * 
         * Author(s):   Michael Beaver
         *                        
         * Input:       N/A  
         * Return:      N/A   
         * Description: 
         *              
         *****************************************************************************************/
        public PSW()
        {
            locContents = new byte[LOC_SIZE];
            condCode = new int[COND_CODE_SIZE];

            InitializeLOCContents();
            InitializeCondCodeContents();
        }

        /******************************************************************************************
         * 
         * Name:        GetBytes     
         * 
         * Author(s):   Michael Beaver
         *                         
         * Input:       The start and end are integers.   
         * Return:      The requested bytes are returned as an array of byte objects.    
         * Description: This method will return an array of byte objects. The array's range will be
         *              inclusive (so, [start, end]). If an error occurs, the returned result will
         *              be null. Otherwise, the returned result will be the array of byte objects.
         *                      
         *****************************************************************************************/
        public byte[] GetBytes(int start, int end)
        {
            /* Do not use a negative range or invalid values. */
            if (end < start || start < 0 || start > LOC_SIZE || end < 0 || end > LOC_SIZE)
                return null;

            /* Inclusive range. */
            byte[] result = new byte[end - start + 1];

            /* Attempt to copy the values. */
            try
            {
                int i = 0;
                int j = start;

                while (j <= end)
                {
                    result[i] = locContents[j];

                    i++;
                    j++;
                }
            }

            /* Index was out of bounds. */
            catch (IndexOutOfRangeException)
            {
                Console.WriteLine("Error: Index out of bounds!");

                result = null;
            }

            return result;
        }

        ///******************************************************************************************
        // * 
        // * Name:        GetByteHex     
        // * 
        // * Author(s):   Michael Beaver
        // *                          
        // * Input:       The index is an integer.    
        // * Return:      The hexadecimal value is a string.  
        // * Description: This method will return the hexadecimal representation of a specified 
        // *              byte (given by "index"). If an error occurs, the returned result will be
        // *              null. Otherwise, the returned result will be the hexadecimal string.
        // *                          
        // *****************************************************************************************/
        //public string GetByteHex(int index)
        //{
        //    string result;

        //    /* Get the hexadecimal representation. */
        //    try
        //    {
        //        result = locContents[index].ToString("X").PadLeft(2, '0');
        //    }

        //    /* Index is out of bounds. */
        //    catch (IndexOutOfRangeException)
        //    {
        //        Console.WriteLine("Error: Index out of bounds!");

        //        result = null;
        //    }

        //    return result;
        //}

        ///******************************************************************************************
        // * 
        // * Name:        GetByteInt     
        // * 
        // * Author(s):   Michael Beaver
        // *              
        // * Input:       The index is an integer.   
        // * Return:      The integer value of the byte is an integer.   
        // * Description: This method will return the integer value of a specified byte (given by
        // *              "index"). If an error occurs, the returned result will be -1. Otherwise,
        // *              the returned result will be the integer value of the byte.
        // *              
        // *****************************************************************************************/
        //public int GetByteInt(int index)
        //{
        //    int result;

        //    /* Get the integer value. */
        //    try
        //    {
        //        result = locContents[index];
        //    }

        //    /* Index is out of bounds. */
        //    catch (IndexOutOfRangeException)
        //    {
        //        Console.WriteLine("Error: Index out of bounds!");

        //        result = -1;
        //    }

        //    return result;
        //}

        /******************************************************************************************
         * 
         * Name:        GetBytesInt     
         * 
         * Author(s):   Michael Beaver 
         *                       
         * Input:       The start and end values are integers.      
         * Return:      The integer value of the bytes is an integer.  
         * Description: This method will return the integer value of a specified inclusive range
         *              of bytes (so, [start, end]). If an error occurs, the returned result will
         *              be -1. Otherwise, the returned result will be the integer value.
         *                 
         *****************************************************************************************/
        public int GetBytesInt(int start, int end)
        {
            string bytesString;
            int result;

            /* Get the sequence of bytes as a string. */
            bytesString = GetBytesString(start, end);

            /* The sequence of bytes does not exist, or an error occurred. */
            if (bytesString == null)
                result = -1;

            /* Actually calculate the integer value, if possible. */
            else
                result = Convert.ToInt32(bytesString, 16);

            return result;
        }

        /******************************************************************************************
         * 
         * Name:        GetBytesString     
         * 
         * Author(s):   Michael Beaver         
         *              
         * Input:       The start and end values are integers. 
         * Return:      The hexadecimal bytes are a string.  
         * Description: This method will return the hexadecimal string of bytes of a specified
         *              inclusive range (so, [start, end]). If an error occurs, the returned
         *              result will be null. Otherwise, the returned result will be the 
         *              hexadecimal string.
         *                     
         *****************************************************************************************/
        public string GetBytesString(int start, int end)
        {
            /* Do not use a negative range or invalid values. */
            if (end < start || start < 0 || start > LOC_SIZE || end < 0 || end > LOC_SIZE)
                return null;

            string result = "";

            /* Create the hexadecimal string. */
            try
            {
                int i = 0;
                int j = start;

                while (j <= end)
                {
                    result += locContents[j].ToString("X").PadLeft(2, '0');

                    i++;
                    j++;
                }
            }

            /* Index was out of bounds. */
            catch (IndexOutOfRangeException)
            {
                Console.WriteLine("Error: Index out of bounds!");

                result = null;
            }

            return result;
        }

        /******************************************************************************************
         * 
         * Name:        GetCondCodeInt     
         * 
         * Author(s):   Michael Beaver 
         *                       
         * Input:       N/A      
         * Return:      The result is an integer.  
         * Description: This method will return the integer value of the condition code.
         *                 
         *****************************************************************************************/
        public int GetCondCodeInt()
        {
            int result;

            /* 00 or 01 implies 0 or 1, respectively. */
            if (condCode[0] == 0)
            {
                if (condCode[1] == 0)
                    result = 0;

                else
                    result = 1;
            }

            /* 10 or 11 implies 2 or 3, respectively. */
            else
            {
                if (condCode[1] == 0)
                    result = 2;

                else
                    result = 3;
            }

            return result;
        }

        /******************************************************************************************
         * 
         * Name:        SetByte    
         * 
         * Author(s):   Michael Beaver      
         *              
         * Input:       The index and value are integers.   
         * Return:      The result is boolean.
         * Description: This method will attempt to set a byte with specified location ("index") to
         *              a new value ("value"). If an error occurs, the returned result will be
         *              false. Otherwise, the returned result will be true.
         *              
         *****************************************************************************************/
        public bool SetByte(int index, int value)
        {
            bool result = false;

            /* Attempt to alter the byte's value. */
            try
            {
                locContents[index] = Byte.Parse(value.ToString());

                result = true;
            }

            /* The index was out of bounds. */
            catch (IndexOutOfRangeException)
            {
                Console.WriteLine("Error: Index out of bounds!");

                result = false;
            }

            return result;
        }

        /******************************************************************************************
         * 
         * Name:        SetByte     
         * 
         * Author(s):   Michael Beaver     
         *              
         * Input:       The index is an integer, and the value is a string.    
         * Return:      The result is boolean.
         * Description: This method will attempt to set a byte with specified location ("index") to
         *              a new value ("value"). The value in "value" should be hexadecimal. If an 
         *              error occurs, the returned result will be false. Otherwise, the returned 
         *              result will be true. 
         *                          
         *****************************************************************************************/
        public bool SetByte(int index, string value)
        {
            bool result = false;
            int tempVal;

            /* Attempt to set the byte to the new value. */
            try
            {
                tempVal = Convert.ToInt32(value, 16);
                locContents[index] = Byte.Parse(tempVal.ToString());

                result = true;
            }

            /* The value could not be converted. */
            catch (OverflowException)
            {
                Console.WriteLine("Error: Overflow during conversion!");

                result = false;
            }

            /* The index is out of bounds. */
            catch (IndexOutOfRangeException)
            {
                Console.WriteLine("Error: Index out of bounds!");

                result = false;
            }

            return result;
        }

        /******************************************************************************************
         * 
         * Name:        SetBytes    
         * 
         * Author(s):   Michael Beaver  
         *                         
         * Input:       The index is an integer, and values is an array of integers.   
         * Return:      The result is boolean.     
         * Description: This method will attempt to set a contiguous sequence of bytes starting at
         *              "index" to a series of values specified by the "values" array. If an error
         *              occurs, the returned result will be false. Otherwise, the returned result
         *              will be true.
         *              
         *****************************************************************************************/
        public bool SetBytes(int index, int[] values)
        {
            bool result = false;

            if (index < 0 || index > LOC_SIZE)
                return result;

            /* Attempt to set the sequence of bytes. */
            try
            {
                /* The offset is used to traverse to the next contiguous byte in memory. */
                int offset = 0;

                foreach (int val in values)
                {
                    locContents[index + offset] = Byte.Parse(val.ToString());

                    if (index + offset == LOC_SIZE)
                        break;

                    offset++;
                }

                result = true;
            }

            /* An index was out of bounds. */
            catch (IndexOutOfRangeException)
            {
                Console.WriteLine("Error: Index out of bounds!");

                result = false;
            }

            return result;
        }

        /******************************************************************************************
         * 
         * Name:        SetBytes     
         * 
         * Author(s):   Michael Beaver  
         *                         
         * Input:       The index is an integer, and values is an array of strings.
         * Return:      The result is boolean.
         * Description: This method will attempt to set a contiguous sequence of bytes starting at
         *              "index" to a series of values specified by the "values" array. The values
         *              in the "values" array should be in hexadecimal representation. If an error
         *              occurs, the returned result will be false. Otherwise, the returned result
         *              will be true.
         *                
         *****************************************************************************************/
        public bool SetBytes(int index, string[] values)
        {
            bool result = false;
            int tempVal;

            if (index < 0 || index > LOC_SIZE)
                return result;

            /* Attempt to set the bytes to the new values. */
            try
            {
                /* The offset is used to traverse to the next contiguous byte in memory. */
                int offset = 0;

                foreach (string val in values)
                {
                    tempVal = Convert.ToInt32(val, 16);
                    locContents[index + offset] = Byte.Parse(tempVal.ToString());

                    if (index + offset == LOC_SIZE)
                        break;

                    offset++;
                }

                result = true;
            }

            /* A value could not be converted. */
            catch (OverflowException)
            {
                Console.WriteLine("Error: Overflow during conversion!");

                result = false;
            }

            /* An index was out of bounds. */
            catch (IndexOutOfRangeException)
            {
                Console.WriteLine("Error: Index out of bounds!");

                result = false;
            }

            return result;
        }

        /******************************************************************************************
         * 
         * Name:        SetCondCode     
         * 
         * Author(s):   Michael Beaver 
         *                       
         * Input:       The value is an integer.      
         * Return:      The result is boolean. 
         * Description: This method will attempt to update the condition code bits based on a 
         *              specified integer value ("value"). The condition code must be in the range
         *              [0, 3]. If an error occurs, the returned result will be false. Otherwise,
         *              the returned result will be true.
         *                 
         *****************************************************************************************/
        public bool SetCondCode(int value)
        {
            bool result = false;

            /* Update the condition code based on the given value. */
            switch (value)
            {
                case 0:
                    {
                        condCode[0] = 0;
                        condCode[1] = 0;

                        result = true;
                        break;
                    }

                case 1:
                    {
                        condCode[0] = 0;
                        condCode[1] = 1;

                        result = true;
                        break;
                    }

                case 2:
                    {
                        condCode[0] = 1;
                        condCode[1] = 0;

                        result = true;
                        break;
                    }

                case 3:
                    {
                        condCode[0] = 1;
                        condCode[1] = 1;

                        result = true;
                        break;
                    }

                /* Invalid value specified. */
                default:
                    {
                        result = false;
                        break;
                    }
            }

            return result;
        }

        /******************************************************************************************
         * 
         * Name:        SetCondCode     
         * 
         * Author(s):   Michael Beaver 
         *                       
         * Input:       High and low are integers.      
         * Return:      The result is boolean. 
         * Description: This method will attempt to update the condition code bits based on  
         *              specified integer values ("high" and "low"). The condition code must be in 
         *              the range [0, 3]. This means "high" and "low" must be either 0 or 1. If an 
         *              error occurs, the returned result will be false. Otherwise, the returned 
         *              result will be true.
         *                 
         *****************************************************************************************/
        public bool SetCondCode(int high, int low)
        {
            bool result;

            /* Do not use invalid values. */
            if (high < 0 || high > 1 || low < 0 || low > 1)
                result = false;

            /* Update the condition code based on the given value. */
            else
            {
                condCode[0] = high;
                condCode[1] = low;

                result = true;
            }
            
            return result;
        }


        /* Private methods. */

        /******************************************************************************************
         * 
         * Name:        InitializeCondCodeContents    
         * 
         * Author(s):   Michael Beaver 
         *                       
         * Input:       N/A
         * Return:      N/A
         * Description: This method is used by the class constructor(s) to initialize the condition
         *              code contents to the DEFAULT_COND_CODE_VALUE. The DEFAULT_COND_CODE_VALUE 
         *              should be 0 or 1.              
         *              
         *****************************************************************************************/
        private void InitializeCondCodeContents()
        {
            for (int i = 0; i < COND_CODE_SIZE; i++)
                condCode[i] = DEFAULT_COND_CODE_VALUE;
        }

        /******************************************************************************************
         * 
         * Name:        InitializeLOCContents    
         * 
         * Author(s):   Michael Beaver 
         *                       
         * Input:       N/A
         * Return:      N/A
         * Description: This method is used by the class constructor(s) to initialize the LOC
         *              contents to the DEFAULT_BYTE_VALUE. The DEFAULT_BYTE_VALUE should be
         *              in hexadecimal.              
         *              
         *****************************************************************************************/
        private void InitializeLOCContents()
        {
            string tempVal;

            /* Set all bytes in memory to the default byte value. */
            for (int i = 0; i < LOC_SIZE; i++)
            {
                tempVal = Convert.ToString(Convert.ToInt32(DEFAULT_BYTE_VALUE, 16));
                locContents[i] = Byte.Parse(tempVal);
            }
        }

    }

}

