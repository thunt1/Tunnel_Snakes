﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Assist_UNA;
using System.IO;

/**************************************************************************************************
 * 
 * Name: Processing
 * 
 * ================================================================================================
 * 
 * Description: This is a static class to take care of managing the backend processing. This 
 *              includes Assembling and Simulating the source code.
 *                       
 * ================================================================================================        
 * 
 * Modification History
 * --------------------
 * 04/05/2014   THH     Original version.
 * 04/08/2014   ACA     Added front end ASSIST option variables and worked on PRT with THH.
 * 04/10/2014   AAH     Uncommented lines so the obj and imf files will be deleted. These can
 *                          be added back for debugging if needed.
 *                      Moved to Processing folder.
 * 04/14/2014   THH     Added preliminary code for debugging and final run modes.
 * 04/15/2014   JMB     Added a new data member for memory size;
 *                       
 *************************************************************************************************/

namespace Assist_UNA
{
    static class Processing
    {
        /* Private members. */
        private static Assembler assembler;
        private static int optionsInstructions;
        private static int optionsLines;
        private static int optionsPages;
        private static MainForm main;
        private static string identifier;
        private static string inputFilePath;
        private static string intermediateFilePath;
        private static string objectFilePath;
        private static string prtFilePath;
        private static string sourceFileDirectory;
        private static string sourceFileName;
        private static string sourceFilePath;
        private static SymbolTable symbolTable;
        private static uint optionsMemorySize;


        /* Public methods. */

        /******************************************************************************************
         * 
         * Name:        Assemble        
         * 
         * Author(s):   Travis Hunt
         *              
         *              
         * Input:       The main form.   
         * Return:      N/A
         * Description: This method will handle the duties of choosing the option to only assemble.
         *              
         *****************************************************************************************/
        public static void Assemble(MainForm mainForm)
        {
            string pass2Return;
            main = mainForm;

            Cursor.Current = Cursors.AppStarting;

            Initialize();

            assembler.Pass1();
            pass2Return = assembler.Pass2();

            if (pass2Return == "IOException")
                main.SetPathPRT(String.Format(@"{0}\{1}.PRT", sourceFileDirectory, sourceFileName));
            else if (pass2Return == "UnauthorizedAccessException")
            {
                File.Delete(intermediateFilePath);
                return;
            }
                
            Cursor.Current = Cursors.Default;

            MessageBox.Show("Your project has been assembled.");

            symbolTable = assembler.GetSymbolTable();
            UpdateSymbolTableDisplay(symbolTable, main);            

            //File.Delete(objectFilePath);
            //File.Delete(intermediateFilePath);
        }

        /******************************************************************************************
         * 
         * Name:        AssembleDebug        
         * 
         * Author(s):   Travis Hunt
         *              
         *              
         * Input:       The main form.   
         * Return:      N/A
         * Description: This method will handle the duties of choosing the option to assemble and
         *              debug.
         *              
         *****************************************************************************************/
        public static void AssembleDebug(MainForm main)
        {
            Cursor.Current = Cursors.AppStarting;

            Initialize();

            assembler.Pass1();
            if (assembler.Pass2() == "IOException")
                main.SetPathPRT(String.Format(@"{0}\{1}.PRT", sourceFileDirectory, sourceFileName));

            Cursor.Current = Cursors.Default;
            File.Delete(intermediateFilePath);

            /* Simulator code follow here. */
            if (assembler.HasErrors())
                MessageBox.Show("Cannot be executed, assembler errors encountered.");
            else
            {
                inputFilePath = assembler.GetInputFile();
                objectFilePath = assembler.GetObjectFile();

                main.SetOutputText("Final Run! The output of the program will go here...");
                main.ShowOutput();
                
            }
            File.Delete(objectFilePath);
            File.Delete(prtFilePath);
        }

        /******************************************************************************************
         * 
         * Name:        AssembleFinalRun  
         * 
         * Author(s):   Travis Hunt
         *              
         *              
         * Input:       The main form.   
         * Return:      N/A
         * Description: This method will handle the duties of choosing the option to assemble and
         *              final run.
         *              
         *****************************************************************************************/
        public static void AssembleFinalRun(MainForm main)
        {
            Cursor.Current = Cursors.AppStarting;

            Initialize();

            identifier = main.GetID();

            assembler.Pass1();
            if (assembler.Pass2() == "IOException")
                main.SetPathPRT(String.Format(@"{0}\{1}.PRT", sourceFileDirectory, sourceFileName));

            Cursor.Current = Cursors.Default;
            File.Delete(intermediateFilePath);

            /* Simulator code follow here. */
            if (assembler.HasErrors())
                MessageBox.Show("Cannot be executed, assembler errors encountered.");

            else
            {
                inputFilePath = assembler.GetInputFile();
                objectFilePath = assembler.GetObjectFile();

                Simulator sim = new Simulator(optionsMemorySize, objectFilePath, prtFilePath, main);

                sim.Simulate();

                main.SetOutputText("Final Run! The output of the program will go here...");
                main.ShowOutput();
            }

            File.Delete(objectFilePath);
        }


        /* Private methods. */

        /******************************************************************************************
         * 
         * Name:        Initialize        
         * 
         * Author(s):   Travis Hunt
         *              
         *              
         * Input:       N/A   
         * Return:      N/A
         * Description: This private method will initialize all the variables to the correct values
         *              sent from the main form.
         *              
         *****************************************************************************************/
        private static void Initialize()
        {
            identifier = "";
            inputFilePath = "";

            sourceFileDirectory = main.GetDirectory();
            sourceFileName = main.GetFileNameProject();

            sourceFilePath = String.Format(@"{0}\{1}.una", sourceFileDirectory, sourceFileName);
            intermediateFilePath = String.Format(@"{0}\{1}.imf", sourceFileDirectory, sourceFileName);
            objectFilePath = String.Format(@"{0}\{1}.obj", sourceFileDirectory, sourceFileName);
            prtFilePath = main.GetPathPRT();

            optionsInstructions = main.GetMaxInstructions();
            optionsLines = main.GetMaxLines();
            optionsPages = main.GetMaxPages();

            assembler = new Assembler(identifier, sourceFilePath, prtFilePath,
                                                        intermediateFilePath, objectFilePath,
                                                        optionsInstructions, optionsLines,
                                                        optionsPages);
        }

        /******************************************************************************************
         * 
         * Name:        UpdateSymbolTableDisplay        
         * 
         * Author(s):   Travis Hunt
         *              
         *              
         * Input:       The symbol table and main form.   
         * Return:      N/A
         * Description: This method will update the symbol table display on the main form.
         *              
         *****************************************************************************************/
        private static void UpdateSymbolTableDisplay(SymbolTable symTable, MainForm main)
        {
            /* Display the symbol table to the main display. */
            string[] symbols = symbolTable.GetSymbolsList();
            string[] addresses = symbolTable.GetAddressesList();

            Array.Sort(addresses, symbols);

            for (int i = 0; i < symbols.Length; i++)
                main.AddSymbolTableEntry(symbols[i], addresses[i]);
        }
    }
}
