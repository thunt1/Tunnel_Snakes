﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**************************************************************************************************
* 
* Name: Bit
* 
* ================================================================================================
* 
* Description: The bit is the most basic representation of memory and register contents. Bits can
*              have the value of either 0 or 1.
*                                
* ================================================================================================        
* 
* Modification History
* --------------------
* 03/25/2014    JMB  Class created.
*                      
*************************************************************************************************/

class Bit
{

    /* Private members. */
    int bit;

    /* Public methods. */

    /******************************************************************************************
     * 
     * Name: Bit       
     * 
     * Author(s): Michael Beaver
     *                         
     * Input: N/A
     * Return: N/A    
     * Description: !!!!!!!!!!!!!!!!!!!!
     *                      
     *****************************************************************************************/
    public Bit()
    {
        bit = 0;
    }

    /******************************************************************************************
     * 
     * Name: Bit       
     * 
     * Author(s): Michael Beaver
     *                         
     * Input: N/A
     * Return: N/A    
     * Description: !!!!!!!!!!!!!!!!!!!!
     *                      
     *****************************************************************************************/
    public Bit(int value)
    {
        if (value < 0)
            bit = 0;

        else
            bit = 1;
    }

    /******************************************************************************************
     * 
     * Name: GetValue       
     * 
     * Author(s): Michael Beaver
     *                         
     * Input: N/A
     * Return: The integer value stored in the Bit.     
     * Description: This method returns the integer value stored in the Bit.
     *                      
     *****************************************************************************************/
    public int GetValue()
    {
        return bit;
    }

    /******************************************************************************************
     * 
     * Name: SetValue       
     * 
     * Author(s): Michael Beaver
     *                       
     * Input: Integer
     * Return: True/False   
     * Description: This method sets the integer value in the Bit. The method will return True
     *              if the newValue is valid, and the method will return false if the newValue
     *              is invalid.          
     *              
     *****************************************************************************************/
    public bool SetValue(int newValue)
    {
        if (newValue < 0 || newValue > 1)
            return false;

        bit = newValue;
        return true;
    }

}
