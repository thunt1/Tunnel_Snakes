﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Byte;

/**************************************************************************************************
* 
* Name: Memory
* 
* ================================================================================================
* 
* Description: !!!!!!!!!!!!!!!!!!!!
*              
*                       
* ================================================================================================        
* 
* Modification History
* --------------------
* 03/25/2014    JMB  Class created.
*                      
*************************************************************************************************/

class Memory
{

    /* Constants. */
    const int MIN_MEMORY_SIZE = 256;

    /* Private members. */
    AssistByte[] contents;
    int memorySize;

    /* Public methods. */

    /******************************************************************************************
     * 
     * Name: Memory
     * 
     * Author(s): Michael Beaver
     *                     
     * Input: !!!!!!!!!!!!!!!!!!!!      
     * Return: !!!!!!!!!!!!!!!!!!!!      
     * Description: !!!!!!!!!!!!!!!!!!!! 
     *              
     *              
     *****************************************************************************************/
    public Memory()
    {
        memorySize = MIN_MEMORY_SIZE;
        contents = new AssistByte[memorySize];
    }

    /******************************************************************************************
     * 
     * Name: Memory
     * 
     * Author(s): Michael Beaver
     *                     
     * Input: !!!!!!!!!!!!!!!!!!!!      
     * Return: !!!!!!!!!!!!!!!!!!!!      
     * Description: !!!!!!!!!!!!!!!!!!!! 
     *              
     *              
     *****************************************************************************************/
    public Memory(int memSize)
    {
        if (memSize < MIN_MEMORY_SIZE)
            memorySize = MIN_MEMORY_SIZE;

        else
            memorySize = memSize;

        contents = new AssistByte[memorySize];
    }

    /******************************************************************************************
     * 
     * Name: GetByte
     * 
     * Author(s): Michael Beaver
     *                     
     * Input: !!!!!!!!!!!!!!!!!!!!      
     * Return: !!!!!!!!!!!!!!!!!!!!      
     * Description: !!!!!!!!!!!!!!!!!!!! 
     *              
     *              
     *****************************************************************************************/
    public AssistByte GetByte(int address)
    {
        if (address >= 0 && address <= memorySize)
            return contents[address];
    }

    /******************************************************************************************
     * 
     * Name: SetByte
     * 
     * Author(s): Michael Beaver
     *                     
     * Input: !!!!!!!!!!!!!!!!!!!!      
     * Return: !!!!!!!!!!!!!!!!!!!!      
     * Description: !!!!!!!!!!!!!!!!!!!! 
     *              
     *              
     *****************************************************************************************/
    public bool SetByte(int address, string hexValue)
    {
        if (contents[i].SetHexValue(hexValue))
            return true;

        return false;
    }


     /* Private methods. */

    /******************************************************************************************
     * 
     * Name: BytesToString
     * 
     * Author(s): Michael Beaver
     *                     
     * Input: !!!!!!!!!!!!!!!!!!!!      
     * Return: !!!!!!!!!!!!!!!!!!!!      
     * Description: !!!!!!!!!!!!!!!!!!!! 
     *              
     *              
     *****************************************************************************************/
    private string BytesToString(int startAddress, int endAddress)
    {
        string result;

        for (int i = startAddress; i < endAddress; i++)
            result += contents[i].GetHexValue();

        return result;
    }

    /******************************************************************************************
     * 
     * Name: StringToBytes
     * 
     * Author(s): Michael Beaver
     *                     
     * Input: !!!!!!!!!!!!!!!!!!!!      
     * Return: !!!!!!!!!!!!!!!!!!!!      
     * Description: !!!!!!!!!!!!!!!!!!!! 
     *              
     *              
     *****************************************************************************************/
    private AssistByte[] StringToBytes(string bytes, int numBytes)
    {
        AssistByte[] result = new AssistByte[numBytes];
        int j = 1;
        string tempHex;

        for (int i = 0; i < numBytes - 1; i++)
        {
            tempHex = bytes[i];
            tempHex += bytes[j];

            result[i].SetHexValue(tempHex);

            j++;
        }

        return result;
    }


}
