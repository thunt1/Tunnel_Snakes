﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LibraryTest;

 /**************************************************************************************************
 * 
 * Name: 
 * 
 * ================================================================================================
 * 
 * Description: 
 *              
 *                       
 * ================================================================================================        
 * 
 * Modification History
 * --------------------
 * 04/04/2014    CAF     Created test driver.
 * 04/04/2014    JMB     Assisted.
 * 04/07/2014    JMB     Added method to test the DB and DXB calculation methods.
 *                          CONCERN: In DXB, when X is 0, we are supposed to use the literal value
 *                          zero, not the contents of Register 0. Right? What about with DB?
 * 04/08/2014    CAF     Assisted JMB with general maintenance and testing conditions.
 * 04/08/2014    JMB     Maintained code and conducted testing.
 *                    
 *************************************************************************************************/

namespace LibraryTest
{
    class LibraryTestDriver
    {
        /* 
         * For testing purposes, we've decided to make the memory portion of this driver public
         * to reflect that the memory will be made public as part of the "processing" portion
         * of the back-end.
         */
        const uint MAIN_MEMORY_SIZE = 256;
        const uint NUM_REGISTERS = 16;

        static void Main(string[] args)
        {
            Memory mainMemory = new Memory(MAIN_MEMORY_SIZE);
            PSW progStatWord = new PSW();
            Register[] registers = new Register[NUM_REGISTERS];
            LibraryTest library = new LibraryTest(mainMemory, registers, progStatWord);
            uint locationCounter = 0;

            InitializeMemory(ref mainMemory);
            InitializeRegisters(ref registers);

            //TestAddressDB(ref mainMemory, ref library);
            //Console.ReadLine();
            //Console.Clear();
            //TestAddressDXB(ref mainMemory, ref library);

            //library.PerformInstructionXDECO(locationCounter);

            // Memory indices:
            // STM 14,12,12(13)     @   0
            // BALR 12,0            @   4
            // ST 13,38(12)         @   6
            // LA 13,34(12)         @   10
            // LA 4,20              @   14
            // LR 3,4               @   18
            // AR 3,4               @   20
            // SR 3,4               @   22
            // XDECO 3,107(12)      @   24
            // L 13,38(12)          @   28
            // LM 14,12,12(13)      @   32
            // BR 14                @   36
            locationCounter = 14;
            library.SimulateInstruction(locationCounter);

            Console.ReadLine();
        }

        /******************************************************************************************
         * 
         * Name:        InitializeMemory 
         * 
         * Author(s):   Michael Beaver     
         *              
         * Input:       mainMemory is a Memory object.
         * Return:      N/A
         * Description: This method will initialize the contents of mainMemory to a series of bytes
         *              (randomly generated) meant to simulate object code.
         *              
         *****************************************************************************************/
        static void InitializeMemory(ref Memory mainMemory)
        {
            /*
            string[] memoryData = {"F2", "44", "20", "00", "20", "05", "E2", "80", "29", "DF", 
                                   "F0", "5D", "13", "A7", "B5", "4B", "F1", "F2", "F3", "F4", 
                                   "F5", "F6", "F7", "F8", "F9", "F0", "C0", "ED", "61", "86", 
                                   "41", "22", "00", "10", "DD", "20", "9B", "93", "D7", "D6", 
                                   "1B", "21", "99", "F3", "8B", "F8", "81", "AC", "0A", "3D", 
                                   "18", "21", "50", "75", "E3", "57", "E1", "71", "BA", "E9", 
                                   "9A", "AE", "5A", "9A", "B4", "08", "4B", "35", "CB", "75", 
                                   "4D", "EF", "63", "04", "09", "00", "48", "74", "98", "E2",
                                   "5C", "1E", "57", "C6", "3C", "94", "D6", "C2", "16", "48", 
                                   "06", "48", "54", "13", "42", "D7", "46", "99", "E1", "89", 
                                   "41", "D3", "AB", "CD", "38", "5C", "F7", "C1", "EF", "AE", 
                                   "87", "C4", "FA", "FD", "1F", "15", "42", "19", "BE", "74", 
                                   "3D", "A5", "3E", "07", "AD", "94", "F7", "4C", "12", "A2", 
                                   "DF", "6F", "79", "A5", "E4", "9F", "F1", "4A", "24", "15", 
                                   "A7", "04", "11", "F9", "F8", "5C", "D7", "27", "DB", "49", 
                                   "B2", "BD", "79", "AF", "D4", "14", "B3", "CD", "04", "F2",
                                   "2D", "DA", "40", "F9", "FF", "F2", "34", "6B", "68", "3C", 
                                   "4E", "FD", "2D", "4A", "97", "61", "5E", "D0", "BD", "14", 
                                   "62", "62", "02", "02", "7C", "AB", "07", "75", "6B", "A4", 
                                   "61", "28", "75", "59", "FB", "A6", "0F", "67", "BE", "82", 
                                   "2B", "4A", "8B", "76", "1D", "79", "AA", "28", "64", "E2", 
                                   "75", "D7", "DD", "D3", "85", "1A", "E5", "61", "4E", "6F", 
                                   "B6", "69", "68", "60", "00", "D0", "DC", "D0", "A0", "6A", 
                                   "1D", "E9", "4E", "8B", "09", "1E", "C6", "E2", "F9", "DF",
                                   "C3", "7D", "BD", "3A", "B1", "30", "A6", "51", "51", "15", 
                                   "17", "8C", "EA", "13", "FC", "D5"}; */
            string[] memoryData = {
                                    "90", "EC", "D0", "0C", "05", "C0", "50", "D0", "C0", "26", 
                                    "41", "D0", "C0", "22", "41", "40", "00", "14", "18", "34", 
                                    "1A", "34", "1B", "34", "52", "30", "C0", "6B", "58", "D0", 
                                    "C0", "26", "98", "EC", "D0", "0C", "07", "FE", "F5", "F5", 
                                    "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", 
                                    "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", 
                                    "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", 
                                    "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", 
                                    "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", 
                                    "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", 
                                    "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", 
                                    "40", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", 
                                    "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", 
                                    "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", 
                                    "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", 
                                    "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", 
                                    "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", 
                                    "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", 
                                    "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", 
                                    "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", 
                                    "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", 
                                    "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", 
                                    "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", 
                                    "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", 
                                    "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", "F5", 
                                    "F5", "F5", "F5", "F5", "F5", "F5"
                                   };

            /* Set each byte in memory. */
            for (uint i = 0; i < MAIN_MEMORY_SIZE; i++)
                mainMemory.SetByte(i, memoryData[i]);
        }

        /******************************************************************************************
         * 
         * Name:        InitializeRegisters
         * 
         * Author(s):   Michael Beaver     
         *              
         * Input:       registers is an array of Register objects.
         * Return:      N/A
         * Description: This method will initialize each Register object to a randomly generated
         *              value (in bytes). These values are meant to mimic actual register contents.
         *              
         *****************************************************************************************/
        static void InitializeRegisters(ref Register[] registers)
        {
            string[] registerContents = {"00", "00", "00", "00",    /* 0. */
                                         "00", "00", "01", "01",    /* 1. */
                                         "00", "00", "00", "10",    /* 2. */
                                         "00", "00", "00", "10",    /* 3. */
                                         "00", "00", "00", "01",    /* 4. */
                                         "00", "00", "11", "03",    /* 5. */
                                         "00", "00", "03", "AF",    /* 6. */
                                         "00", "00", "00", "FF",    /* 7. */
                                         "00", "00", "00", "0A",    /* 8. */
                                         "00", "00", "02", "03",    /* 9. */
                                         "00", "00", "00", "FD",    /* A. */
                                         "00", "00", "00", "00",    /* B. */
                                         "00", "00", "00", "06",    /* C. */
                                         "00", "00", "00", "00",    /* D. */
                                         "00", "00", "00", "1F",    /* E. */
                                         "00", "00", "00", "1C"};   /* F. */
            uint j = 0;

            for (uint i = 0; i < NUM_REGISTERS; i++)
            {
                registers[i] = new Register();

                /* Set each byte. */
                registers[i].SetByte(0, registerContents[j]);
                registers[i].SetByte(1, registerContents[j + 1]);
                registers[i].SetByte(2, registerContents[j + 2]);
                registers[i].SetByte(3, registerContents[j + 3]);

                j += 4;
            }
                
        }

        /******************************************************************************************
         * 
         * Name:        TestAddressDB
         * 
         * Author(s):   Michael Beaver     
         *              
         * Input:       mainMemory is a Memory object, and library is a LibraryTest object.
         * Return:      N/A
         * Description: This method will test the DetermineAddressDB method of the LibraryTest
         *              class. All data used to calculate the address is displayed to the Console.
         *              
         *****************************************************************************************/
        static void TestAddressDB(ref Memory mainMemory, ref LibraryTest library)
        {
            uint address;

            Console.WriteLine("================================================================");
            Console.WriteLine("                 Testing DB Address Calculation                 ");
            Console.WriteLine("================================================================");

            Console.WriteLine("Object Code Address (uint) in Memory (will get 2 bytes): ");
            address = Convert.ToUInt32(Console.ReadLine());

            /* Display results. */
            //Console.WriteLine("Bytes: {0}", 
            //    mainMemory.GetBytesString(address, address + 1));
            //Console.WriteLine("\nDB Address: {0}", 
            //    library.DetermineAddressDB(address).ToString("X"));
        }

        /******************************************************************************************
         * 
         * Name:        TestAddressDXB
         * 
         * Author(s):   Michael Beaver     
         *              
         * Input:       mainMemory is a Memory object, and library is a LibraryTest object.
         * Return:      N/A
         * Description: This method will test the DetermineAddressDXB method of the LibraryTest
         *              class. All data used to calculate the address is displayed to the Console.
         *              
         *****************************************************************************************/
        static void TestAddressDXB(ref Memory mainMemory,  ref LibraryTest library)
        {
            uint address;

            Console.WriteLine("================================================================");
            Console.WriteLine("                 Testing DXB Address Calculation                ");
            Console.WriteLine("================================================================");

            Console.WriteLine("Object Code Address (uint) in Memory (will get 3 bytes): ");
            address = Convert.ToUInt32(Console.ReadLine());

            /* Display the results. */
            //Console.WriteLine("Bytes: {0}", 
            //    mainMemory.GetBytesString(address, address + 2));
            //Console.WriteLine("\nDXB Address: {0}", 
            //    library.DetermineAddressDXB(address).ToString("X"));
        }

    }

}
