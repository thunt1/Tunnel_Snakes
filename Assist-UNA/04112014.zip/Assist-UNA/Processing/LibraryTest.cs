﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Assist_UNA;

/**************************************************************************************************
 * 
 * Name: LibraryTest
 * 
 * ================================================================================================
 * 
 * Description: This class represents all available instructions available to the ASSIST/UNA 
 *              assembly language. Interaction with this class should be done through the public
 *              method SimulateInstruction, which will then call the necessary methods to perform
 *              the intended operations as specified in the object code. 
 *                       
 * ================================================================================================        
 * 
 * Modification History
 * --------------------
 * 04/04/2014   CAF     Created class LibraryTest class and created the initial switch statement
 * 04/05/2014   CAF     Created shell functions for each of the methods, added headers for the class
 *                          and each of its methods, assisted in the address calculation methods.
 * 04/05/2014   JMB     Created the address calculation methods, started the test driver.
 * 04/07/2014   JMB     Removed unnecessary uint to int type conversions. Updated DetermineAddressDB
 *                          and DetermineAddressDXB methods. Added Console output for testing.
 * 04/08/2014   CAF     Created additional helper functions for processing the different types of 
 *                          instructions. Created a rough draft of the Add instruction to test the
 *                          test the new helper function layout. Completed several instruction
 *                          methods.
 * 04/08/2014   JMB     Corrected a mistake in the DetermineAddressDB and DetermineAddressDXB 
 *                          methods. Added and modified Travis's ToEBCDIC method. Completed several
 *                          instruction methods. CONCERN: For DXB addresses, when the Base register
 *                          is Register 0, do we use its contents or the value zero?
 * 04/09/2014   JMB     Updated DetermineAddressDB and DetermineAddressDXB to always use the value
 *                          zero rather than the contents of Register 0.
 * 04/10/2014   CAF     Updated comment sections and cleaned up a few of the functions.
 *                       
 *************************************************************************************************/

namespace Assist_UNA
{
    class LibraryTest
    {
        /* Private members. */

        /* REGISTER_SIZE is Size-1 to offset the start at 0. Size is 4, thus 4-1. */
        const int REGISTER_SIZE = 3;
        const uint DOUBLEWORD = 8;
        const uint FULLWORD = 4;
        const uint HALFWORD = 2;
        const uint MAX_REGISTER = 15;

        Memory mainMemory;
        PSW progStatWord;
        Register[] registers;
        

        /* Public methods. */

        /******************************************************************************************
         * 
         * Name:        LibraryTest
         * 
         * Author(s):   Chad Farley     
         *              
         * Input:       The mainMemoryDriver is a Memory object, the registersDriver is an array
         *                  of register objects, and the progStatWordDriver is a PSW object.
         * Return:      N/A
         * Description: This is the constructor for the LibraryTest class. This constructor will
         *              save references to the parameters so that the methods will be able to access
         *              these data structures and modify the contents.
         *              
         *****************************************************************************************/
        public LibraryTest(Memory mainMemoryDriver, Register[] registersDriver, 
            PSW progStatWordDriver)
        {
            mainMemory = mainMemoryDriver;
            registers = registersDriver;
            progStatWord = progStatWordDriver;
        }

        /******************************************************************************************
         * 
         * Name:        SimulateInstruction
         * 
         * Author(s):   Chad Farley
         *                 
         * Input:       The locationCounter is an unsigned integer, andmainMemory is a 
         *                  Memory object.
         * Return:      N/A
         * Description: This method will access in mainMemory at locationCounter to read in the 
         *              appropriate object code to determine which operation is to be performed,
         *              gather all pertinent information according to the object code, and pass
         *              this information to the appropriate method in accordance with the object
         *              code. 
         *              
         *****************************************************************************************/
        public void SimulateInstruction(uint locationCounter)
        {
            switch (mainMemory.GetByteHex(locationCounter))
            {
                /* A - Add */
                case "5A":
                    PerformInstructionA(locationCounter);
                    break;
                /* AP - Add Packed */
                case "FA":
                    PerformInstructionAP(locationCounter);
                    break;
                /* AR - Add Register */
                case "1A":
                    PerformInstructionAR(locationCounter);
                    break;
                /* BAL - Branch and Link */
                case "45":
                    PerformInstructionBAL(locationCounter);
                    break;
                /* BALR - Branch and Link Register */
                case "05":
                    PerformInstructionBALR(locationCounter);
                    break;
                /* BC - Branch on Condition */
                case "47":
                    PerformInstructionBC(locationCounter);
                    break;
                /* BCR - Branch on Condition Register */
                case "07":
                    PerformInstructionBCR(locationCounter);
                    break;
                /* BCT - Branch on Count */
                case "46":
                    PerformInstructionBCT(locationCounter);
                    break;
                /* BCTR - Branch on Count Register */
                case "06":
                    PerformInstructionBCTR(locationCounter);
                    break;
                /* BXH - Branch on Index High */
                case "86":
                    PerformInstructionBXH(locationCounter);
                    break;
                /* BXLE - Branch on Index Low or Equal */
                case "87":
                    PerformInstructionBXLE(locationCounter);
                    break;
                /* C - Compare */
                case "59":
                    PerformInstructionC(locationCounter);
                    break;
                /* CLC - Compare Logical Characters */
                case "D5":
                    PerformInstructionCLC(locationCounter);
                    break;
                /* CLI - Compare Logical Immediate */
                case "95":
                    PerformInstructionCLI(locationCounter);
                    break;
                /* CP - Compare Packed */
                case "F9":
                    PerformInstructionCP(locationCounter);
                    break;
                /* CR - Compare Register */
                case "19":
                    PerformInstructionCR(locationCounter);
                    break;
                /* D - Divide */
                case "5D":
                    PerformInstructionD(locationCounter);
                    break;
                /* DP - Divide Packed */
                case "FD":
                    PerformInstructionDP(locationCounter);
                    break;
                /* DR - Divide Register */
                case "1D":
                    PerformInstructionDR(locationCounter);
                    break;
                /* ED - Edit */
                case "DE":
                    PerformInstructionED(locationCounter);
                    break;
                /* EDMK - Edit and Mark */
                case "DF":
                    PerformInstructionEDMK(locationCounter);
                    break;
                /* L - Load */
                case "58":
                    PerformInstructionL(locationCounter);
                    break;
                /* LA - Load Address */
                case "41":
                    PerformInstructionLA(locationCounter);
                    break;
                /* LM - Load Multiple */
                case "98":
                    PerformInstructionLM(locationCounter);
                    break;
                /* LR - Load Register */
                case "18":
                    PerformInstructionLR(locationCounter);
                    break;
                /* M - Multiply */
                case "5C":
                    PerformInstructionM(locationCounter);
                    break;
                /* MP - Multiply Packed */
                case "FC":
                    PerformInstructionMP(locationCounter);
                    break;
                /* MR - Multiply Register */
                case "1C":
                    PerformInstructionMR(locationCounter);
                    break;
                /* MVC - Move Characters */
                case "D2":
                    PerformInstructionMVC(locationCounter);
                    break;
                /* MVI - Move Immediate */
                case "92":
                    PerformInstructionMVI(locationCounter);
                    break;
                /* N - Bitwise AND */
                case "54":
                    PerformInstructionN(locationCounter);
                    break;
                /* NR - Bitwise AND Register */
                case "14":
                    PerformInstructionNR(locationCounter);
                    break;
                /* O - Bitwise OR */
                case "56":
                    PerformInstructionO(locationCounter);
                    break;
                /* OR - Bitwise OR Register */
                case "16":
                    PerformInstructionOR(locationCounter);
                    break;
                /* PACK - Pack */
                case "F2":
                    PerformInstructionPACK(locationCounter);
                    break;
                /* S - Subtract */
                case "5B":
                    PerformInstructionS(locationCounter);
                    break;
                /* SP - Subtract Packed */
                case "FB":
                    PerformInstructionSP(locationCounter);
                    break;
                /* SR - Subtract Register */
                case "1B":
                    PerformInstructionSR(locationCounter);
                    break;
                /* ST - Store */
                case "50":
                    PerformInstructionST(locationCounter);
                    break;
                /* STM - Store Multiple */
                case "90":
                    PerformInstructionSTM(locationCounter);
                    break;
                /* UNPK - Unpack */
                case "F3":
                    PerformInstructionUNPK(locationCounter);
                    break;
                /* XDECI - Convert Input to Decimal*/
                case "53":
                    PerformInstructionXDECI(locationCounter);
                    break;
                /* XDECO - Convert Output to Decimal */
                case "52":
                    PerformInstructionXDECO(locationCounter);
                    break;
                /* XPRNT/XREAD */
                case "E0":
                    /* XPRNT - Print Output */
                    if (mainMemory.GetByteHex(locationCounter + 1) == "20")
                    {
                        PerformInstructionXPRNT(locationCounter);
                    }
                    /* XREAD - Read Input */
                    else if (mainMemory.GetByteHex(locationCounter = 1) == "00")
                    {
                        PerformInstructionXREAD(locationCounter);
                    }
                    /* ERROR */
                    else
                    {

                    }
                    break;
                /* ZAP - Zero, Add Packed */
                case "F8":
                    PerformInstructionZAP(locationCounter);
                    break;
                /* ERROR */
                default:
                    break;
            };
        }


        /* Protected methods. */

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *                    
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        protected string AddPackedValues(string operand1, string operand2)
        {
            string result;
            int operand1Value = 0;
            int operand2Value = 0;
            int sum = 0;

            /* Get integer values. */
            operand1Value = Convert.ToInt32(operand1.Substring(0, operand1.Length - 1), 10);
            operand2Value = Convert.ToInt32(operand2.Substring(0, operand2.Length - 1), 10);

            /* Checking for negative signs. */
            if (operand1[operand1.Length - 1] == 'B' || operand1[operand1.Length - 1] == 'D')
                operand1Value *= -1;

            if (operand2[operand2.Length - 1] == 'B' || operand2[operand2.Length - 1] == 'D')
                operand2Value *= -1;

            sum = operand1Value + operand2Value;
            result = sum.ToString();

            /* Add appropriate sign. */
            if (sum < 0)
            {
                result += "D";
                result = result.Replace("-", "0");
            }
                
            else
                result += "C";

            result = result.PadLeft(operand1.Length, '0');

            return result;
        }

        /******************************************************************************************
         * 
         * Name:        DetermineAddressDB
         * 
         * Author(s):   Chad Farley
         *              Michael Beaver
         *              
         * Input:       The addressStart is an unsigned integer.
         * Return:      An integer value that is an index into mainMemory.
         * Description: This method is used to determine what address location in memory is to be
         *                  accessed. This method will add the displacement and the contents of the
         *                  base register to calculate the address in memory.
         *              
         *****************************************************************************************/
        protected uint DetermineAddressDB(uint addressStart)
        {
            uint displacement = 0;
            uint index = 0;
            uint regNo = 0;
            uint regValue = 0;
            string addressParameters;

            addressParameters = mainMemory.GetBytesString(addressStart, addressStart + 1);
            displacement = Convert.ToUInt32(addressParameters.Substring(1, 3), 16);
            regNo = Convert.ToUInt32(addressParameters[0].ToString(), 16);
            regValue = Convert.ToUInt32(registers[regNo].GetBytesString(0, 3), 16);

            /* Do not use the contents of Register 0. */
            if (regNo == 0)
                regValue = 0;

            else
                regValue = Convert.ToUInt32(registers[regNo].GetBytesString(0, 3), 16);

            index = displacement + regValue;

            return index;
        }

        /******************************************************************************************
         * 
         * Name:        DetermineAddressDXB
         * 
         * Author(s):   Chad Farley
         *              Michael Beaver
         *              
         * Input:       The addressStart is an unsigned integer.
         * Return:      An integer value that is an index into mainMemory.
         * Description: This method is used to determine what address location in memory is to be
         *                  accessed. This method will add the displacement and the contents of the
         *                  base register and the index register to calculate the address in memory.  
         *              
         *****************************************************************************************/
        protected uint DetermineAddressDXB(uint addressStart)
        {
            uint displacement = 0;
            uint baseRegNo = 0;
            uint baseRegValue = 0;
            uint index = 0;
            uint indexRegNo = 0;
            uint indexRegValue = 0;
            string addressParameters;

            addressParameters = mainMemory.GetBytesString(addressStart, addressStart + 2);

            indexRegNo = Convert.ToUInt32(addressParameters[1].ToString(), 16);
            baseRegNo = Convert.ToUInt32(addressParameters[2].ToString(), 16);

            displacement = Convert.ToUInt32(addressParameters.Substring(3, 3), 16);
            baseRegValue = Convert.ToUInt32(registers[baseRegNo].GetBytesString(0, 3), 16);

            /* Do not use the contents of Register 0. */
            if (indexRegNo == 0)
                indexRegValue = 0;

            else
                indexRegValue = Convert.ToUInt32(registers[indexRegNo].GetBytesString(0, 3), 16);

            /* Do not use the contents of Register 0. */
            if (baseRegNo == 0)
                baseRegValue = 0;

            else
                baseRegValue = Convert.ToUInt32(registers[baseRegNo].GetBytesString(0, 3), 16);

            index = baseRegValue + indexRegValue + displacement;

            return index;
        }

        /******************************************************************************************
         * 
         * Name:       ProcessTypeRX 
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        protected void ProcessTypeRX
            (uint locationCounter, out uint operandRegister, out uint operandAddress)
        {
            string byteParse;

            byteParse = mainMemory.GetBytesString(locationCounter + 1, locationCounter + 1);
            operandAddress = DetermineAddressDXB(locationCounter + 1);
            operandRegister = Convert.ToUInt32(byteParse[0].ToString(), 16);
        }

        /******************************************************************************************
         * 
         * Name:        ProcessTypeRR
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        protected void ProcessTypeRR
            (uint locationCounter, out uint operandRegister1, out uint operandRegister2)
        {
            string byteParse;

            byteParse = mainMemory.GetBytesString(locationCounter + 1, locationCounter + 1);
            operandRegister1 = Convert.ToUInt32(byteParse[0].ToString(), 16);
            operandRegister2 = Convert.ToUInt32(byteParse[1].ToString(), 16);
        }

        /******************************************************************************************
         * 
         * Name:        ProcessTypeSS
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        protected void ProcessTypeSS
            (uint locationCounter, out uint length1, out uint length2, 
            out uint operandAddress1, out uint operandAddress2)
        {
            string byteParse;

            byteParse = mainMemory.GetBytesString(locationCounter + 1, locationCounter + 1);
            length1 = Convert.ToUInt32(byteParse[0].ToString(), 16) + 1;
            length2 = Convert.ToUInt32(byteParse[1].ToString(), 16) + 1;
            operandAddress1 = DetermineAddressDB(locationCounter + 2);
            operandAddress2 = DetermineAddressDB(locationCounter + 4);
        }

        /******************************************************************************************
         * 
         * Name:        ProcessTypeSSL
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        protected void ProcessTypeSSL
            (uint locationCounter, out int length, 
            out uint operandAddress1, out uint operandAddress2)
        {
            length = mainMemory.GetByteInt(locationCounter + 1) + 1;
            operandAddress1 = DetermineAddressDB(locationCounter + 2);
            operandAddress2 = DetermineAddressDB(locationCounter + 4);
        }

        /******************************************************************************************
         * 
         * Name:        ProcessTypeRS
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        protected void ProcessTypeRS
            (uint locationCounter, out uint operandRegister1, 
            out uint operandRegister2, out uint operandAddress)
        {
            string byteParse;

            byteParse = mainMemory.GetBytesString(locationCounter + 1, locationCounter + 1);
            operandRegister1 = Convert.ToUInt32(byteParse[0].ToString(), 16);
            operandRegister2 = Convert.ToUInt32(byteParse[1].ToString(), 16);
            operandAddress = DetermineAddressDB(locationCounter + 2);
        }

        /******************************************************************************************
         * 
         * Name:        ProcessTypeSI
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        protected void ProcessTypeSI
            (uint locationCounter, out uint operandAddress)
        {
            operandAddress = DetermineAddressDB(locationCounter + 2);
        }

        /******************************************************************************************
         * 
         * Name:        ProcessTypeX
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        protected void ProcessTypeX
            (uint locationCounter, out uint operandAddress)
        {
            operandAddress = DetermineAddressDXB(locationCounter + 1);
        }

        /******************************************************************************************
         * 
         * Name:        ToEBCDIC   
         * 
         * Author(s):   Travis Hunt
         *              Michael Beaver
         *                  
         * Input:       The value is a char to be converted. 
         * Return:      The result is a string of the EBCDIC character code.
         * Description: This method will return the EBCDIC character code for the input char.
         * 
         *              This code is an altered version based off the code found at the following:
         *              http://kodesharp.blogspot.com/2007/12/c-convert-ascii-to-ebcdic.html
         *              
         *****************************************************************************************/
        protected string ToEBCDIC(string value)
        {
            char tempChar;
            int[] a2e = new int[256]{
                                        0, 1, 2, 3, 55, 45, 46, 47, 22, 5, 37, 11, 12, 13, 14, 15,
                                        16, 17, 18, 19, 60, 61, 50, 38, 24, 25, 63, 39, 28, 29, 30, 31,
                                        64, 79,127,123, 91,108, 80,125, 77, 93, 92, 78,107, 96, 75, 97,
                                        240,241,242,243,244,245,246,247,248,249,122, 94, 76,126,110,111,
                                        124,193,194,195,196,197,198,199,200,201,209,210,211,212,213,214,
                                        215,216,217,226,227,228,229,230,231,232,233, 74,224, 90, 95,109,
                                        121,129,130,131,132,133,134,135,136,137,145,146,147,148,149,150,
                                        151,152,153,162,163,164,165,166,167,168,169,192,106,208,161, 7,
                                        32, 33, 34, 35, 36, 21, 6, 23, 40, 41, 42, 43, 44, 9, 10, 27,
                                        48, 49, 26, 51, 52, 53, 54, 8, 56, 57, 58, 59, 4, 20, 62,225,
                                        65, 66, 67, 68, 69, 70, 71, 72, 73, 81, 82, 83, 84, 85, 86, 87,
                                        88, 89, 98, 99,100,101,102,103,104,105,112,113,114,115,116,117,
                                        118,119,120,128,138,139,140,141,142,143,144,154,155,156,157,158,
                                        159,160,170,171,172,173,174,175,176,177,178,179,180,181,182,183,
                                        184,185,186,187,188,189,190,191,202,203,204,205,206,207,218,219,
                                        220,221,222,223,234,235,236,237,238,239,250,251,252,253,254,255
                                        };
            string result = "";

            try
            {
                for (int i = 0; i < value.Length; i++)
                {
                    tempChar = Convert.ToChar(a2e[(int)value[i]]);
                    result += Convert.ToInt32(tempChar).ToString("X");
                }
                //result += Convert.ToInt32(Convert.ToChar(a2e[(int)value[val]])).ToString("X");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                result = null;
            }

            //result = Convert.ToInt32(value).ToString("X");

            return result;
        }


        /* Private methods. */

        /******************************************************************************************
         * 
         * Name:        PerformInstructionA
         * 
         * Author(s):   Chad Farley
         *              Michael Beaver              
         *              
         * Input:       The locationCounter variable is an unsigned integer.
         * Return:      N/A
         * Description: This method takes in as a parameter a pointer into mainMemory that points 
         *              to the object code that contains the additional information needed to 
         *              process the intended operation. This method adds the contents at the address
         *              specified in the object code with the contents of register specified in the
         *              object code and stores it within the register. 
         *              
         *****************************************************************************************/
        private void PerformInstructionA(uint locationCounter)
        {
            uint operandRegister;
            uint operandAddress;
            int registerValue;
            int addressValue;

            ProcessTypeRX(locationCounter, out operandRegister, out operandAddress);
            registerValue = registers[operandRegister].GetBytesInt(0,3);
            addressValue = mainMemory.GetBytesInt(operandAddress, operandAddress + 3);
            registerValue += addressValue;

            registers[operandRegister].SetBytes(0, registerValue);
        }

        /******************************************************************************************
         * 
         * Name:        PerformInstructionAP
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionAP(uint locationCounter)
        {

        }

        /******************************************************************************************
         * 
         * Name:        PerformInstructionAR
         * 
         * Author(s):   Chad Farley
         *              Michael Beaver
         *              
         * Input:       The locationCounter is an unsigned integer.
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        public void PerformInstructionAR(uint locationCounter)
        {
            uint operandRegister1;
            uint operandRegister2;
            int register1Value;
            int register2Value;

            ProcessTypeRR(locationCounter, out operandRegister1, out operandRegister2);
            register1Value = registers[operandRegister1].GetBytesInt(0,3);
            register2Value = registers[operandRegister2].GetBytesInt(0,3);
            register1Value += register2Value;

            registers[operandRegister1].SetBytes(0, register1Value);
        }

        /******************************************************************************************
         * 
         * Name:        PerformInstructionBAL
         * 
         * Author(s):   Chad Farley
         *              Michael Beaver
         *              
         * Input:       The locationCounter is an unsigned integer.
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionBAL(uint locationCounter)
        {
            uint operandRegister;
            uint operandAddress;
            int registerValue;
            //int addressValue;

            ProcessTypeRX(locationCounter, out operandRegister, out operandAddress);
            registerValue = registers[operandRegister].GetBytesInt(0,3);


        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionBALR(uint locationCounter)
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionBC(uint locationCounter)
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionBCR(uint locationCounter)
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionBCT(uint locationCounter)
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionBCTR(uint locationCounter)
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionBXH(uint locationCounter)
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionBXLE(uint locationCounter)
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionC(uint locationCounter)
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionCLC(uint locationCounter)
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionCLI(uint locationCounter)
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionCP(uint locationCounter)
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionCR(uint locationCounter)
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionD(uint locationCounter)
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionDP(uint locationCounter)
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionDR(uint locationCounter)
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionED(uint locationCounter)
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionEDMK(uint locationCounter)
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionL(uint locationCounter)
        {

        }

        /******************************************************************************************
         * 
         * Name:        PerformInstructionLA
         * 
         * Author(s):   Chad Farley
         *              Michael Beaver
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionLA(uint locationCounter)
        {
            uint operandRegister;
            uint operandAddress;

            ProcessTypeRX(locationCounter, out operandRegister, out operandAddress);

            registers[operandRegister].SetBytes(0, 
                operandAddress.ToString("X").PadLeft((REGISTER_SIZE + 1) * 2, '0'));
        }

        /******************************************************************************************
         * 
         * Name:        PerformInstructionLM
         * 
         * Author(s):   Chad Farley
         *              Michael Beaver
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionLM(uint locationCounter)
        {
            string registerContent;
            uint operandAddress;
            uint operandRegister1;
            uint operandRegister2;
            uint registerIndex;
            uint storageIndex = 0;

            ProcessTypeRS(locationCounter, out operandRegister1, out operandRegister2, out operandAddress);
            registerIndex = operandRegister1;

            /* Traverse the registers and load their contents from memory. */
            do
            {
                registerContent = mainMemory.GetBytesString(operandAddress + storageIndex, 
                    operandAddress + storageIndex + FULLWORD - 1);
                registers[registerIndex].SetBytes(0, registerContent);
                storageIndex += FULLWORD;

                /* Special condition: Registers are the same. */
                if (registerIndex == operandRegister2)
                    registerIndex = operandRegister2 + 1;

                else if (registerIndex == MAX_REGISTER)
                    registerIndex = 0;

                else
                    registerIndex++;

            } while (registerIndex != operandRegister2 + 1);
        }

        /******************************************************************************************
         * 
         * Name:        PerformInstructionLR
         * 
         * Author(s):   Michael Beaver       
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionLR(uint locationCounter)
        {
            uint operandRegister1;
            uint operandRegister2;
            int register1Value;
            int register2Value;

            ProcessTypeRR(locationCounter, out operandRegister1, out operandRegister2);
            register1Value = registers[operandRegister1].GetBytesInt(0, REGISTER_SIZE);
            register2Value = registers[operandRegister2].GetBytesInt(0, REGISTER_SIZE);

            registers[operandRegister1].SetBytes(0, 
                register2Value.ToString("X").PadLeft((REGISTER_SIZE + 1) * 2, '0'));
        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionM(uint locationCounter)
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionMP(uint locationCounter)
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionMR(uint locationCounter)
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionMVC(uint locationCounter)
        {
            int length;
            uint operandAddress1;
            uint operandAddress2;
            string address2Content;

            ProcessTypeSSL(locationCounter, out length, out operandAddress1, out operandAddress2);
            address2Content = mainMemory.GetBytesString(operandAddress2, operandAddress2 + (uint)length - 1);
            mainMemory.SetBytes(operandAddress1, address2Content);
        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionMVI(uint locationCounter)
        {
            uint operandAddress;
            string data;

            ProcessTypeSI(locationCounter, out operandAddress);
            data = mainMemory.GetByteHex(locationCounter + 1);
            mainMemory.SetByte(operandAddress, data);
        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionN(uint locationCounter)
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionNR(uint locationCounter)
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionO(uint locationCounter)
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionOR(uint locationCounter)
        {

        }

        /******************************************************************************************
         * 
         * Name:        PerformInstructionPACK
         * 
         * Author(s):   Michael Beaver    
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionPACK(uint locationCounter)
        {
            string operandValue2;
            string result = "";
            string zone;
            uint length1;
            uint length2;
            uint lengthDiff;
            uint operandAddress1;
            uint operandAddress2;

            ProcessTypeSS(locationCounter, out length1, out length2,
                out operandAddress1, out operandAddress2);

            operandValue2 = mainMemory.GetBytesString(operandAddress2,
                operandAddress2 + length2 - 1);

            /* Reverse the zone byte. */
            for (int i = 0; i < (length2 * 2) - 2; i++)
                result += operandValue2[i].ToString();
            zone = operandValue2[((int)length2 * 2) - 2].ToString();
            result = result.Insert(((int)length2 * 2) - 2, 
                operandValue2[((int)length2 * 2) - 1].ToString());

            /* Strip zone characters and append final zone. */
            result = result.Replace("F", "");
            result += zone;
            result = result.PadLeft((int)length2 * 2, '0');

            /* Case 1: First operand is too small. Lose most significant digits without error. */
            if (length1 < length2)
            {
                lengthDiff = (length2 * 2) - (length1 * 2) + 1;

                /* Truncate the most significant digits. */
                if (lengthDiff % 2 == 1)
                    result = result.Substring((int)lengthDiff - 1);

                /* I'm not sure if this clause is necessary. */
                else
                    result = result.Substring((int)lengthDiff);
            }

            /* Case 2: First operand is too large. Pad with leading zeros. */
            else if (length1 > length2)
                result = result.PadLeft((int)length1 * 2, '0');

            mainMemory.SetBytes(operandAddress1, result);
        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionS(uint locationCounter)
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionSP(uint locationCounter)
        {

        }

        /******************************************************************************************
         * 
         * Name:        PerformInstructionSR
         * 
         * Author(s):   Michael Beaver
         *                    
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionSR(uint locationCounter)
        {
            uint operandRegister1;
            uint operandRegister2;
            int register1Value;
            int register2Value;

            ProcessTypeRR(locationCounter, out operandRegister1, out operandRegister2);
            register1Value = registers[operandRegister1].GetBytesInt(0, 3);
            register2Value = registers[operandRegister2].GetBytesInt(0, 3);
            register1Value -= register2Value;

            registers[operandRegister1].SetBytes(0, register1Value);
        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionST(uint locationCounter)
        {

        }

        /******************************************************************************************
         * 
         * Name:        PerformInstructionSTM
         * 
         * Author(s):   Chad Farley
         *              Michael Beaver
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionSTM(uint locationCounter)
        {
            string registerContent;
            uint operandAddress;
            uint operandRegister1;
            uint operandRegister2;
            uint registerIndex;
            uint storageIndex = 0;

            ProcessTypeRS(locationCounter, out operandRegister1, out operandRegister2, out operandAddress);
            registerIndex = operandRegister1;

            /* Traverse the registers and save their contents to memory. */
            do
            {
                registerContent = registers[registerIndex].GetBytesString(0, REGISTER_SIZE);
                mainMemory.SetBytes(operandAddress + storageIndex, registerContent);
                storageIndex += FULLWORD;

                /* Special condition: Registers are the same. */
                if (registerIndex == operandRegister2)
                    registerIndex = operandRegister2 + 1;

                else if (registerIndex == MAX_REGISTER)
                    registerIndex = 0;

                else
                    registerIndex++;

            } while(registerIndex != operandRegister2 + 1);
        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionUNPK(uint locationCounter)
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionXDECI(uint locationCounter)
        {

        }

        /******************************************************************************************
         * 
         * Name:        PerformInstructionXDECO
         * 
         * Author(s):   Chad Farley
         *              Michael Beaver
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        public void PerformInstructionXDECO(uint locationCounter)
        {
            uint operandRegister;
            uint operandAddress;
            int registerValue;
            string convertedValue;

            ProcessTypeRX(locationCounter, out operandRegister, out operandAddress);
            registerValue = registers[operandRegister].GetBytesInt(0, REGISTER_SIZE);
            convertedValue = registerValue.ToString().PadLeft(12, ' ');
            convertedValue = ToEBCDIC(convertedValue);
            

            mainMemory.SetBytes(operandAddress, convertedValue);
        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionXPRNT(uint locationCounter)
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionXREAD(uint locationCounter)
        {

        }

        /******************************************************************************************
         * 
         * Name:        PerformInstructionZAP
         * 
         * Author(s):   Michael Beaver 
         *                       
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionZAP(uint locationCounter)
        {
            string operandValue1;
            string operandValue2;
            string result;
            uint length1;
            uint length2;
            uint operandAddress1;
            uint operandAddress2;

            ProcessTypeSS(locationCounter, out length1, out length2, 
                out operandAddress1, out operandAddress2);

            /* Zero out the memory location. */
            for (uint i = 0; i < length1; i++)
                mainMemory.SetByte(operandAddress1 + i, 0);
            mainMemory.SetByte(operandAddress1 + length1 - 1, "0F");

            /* This value DOES NOT need to be valid packed. */
            operandValue1 = mainMemory.GetBytesString(operandAddress1, 
                operandAddress1 + length1 - 1);

            /* This value MUST be valid packed. */
            operandValue2 = mainMemory.GetBytesString(operandAddress2, 
                operandAddress2 + length2 - 1);

            result = AddPackedValues(operandValue1, operandValue2);
            mainMemory.SetBytes(operandAddress1, result);
        }

        
    }
}
