﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Assist_UNA;
using System.IO;

/**************************************************************************************************
 * 
 * Name: Processing
 * 
 * ================================================================================================
 * 
 * Description: This is a static class to take care of managing the backend processing. This 
 *              includes Assembling and Simulating the source code.
 *                       
 * ================================================================================================        
 * 
 * Modification History
 * --------------------
 * 04/05/2014   THH     Original version.
 * 04/08/2014   ACA     Added front end ASSIST option variables and worked on PRT with THH.
 * 04/10/2014   AAH     Uncommented lines so the obj and imf files will be deleted. These can
 *                          be added back for debugging if needed.
 *                      Moved to Processing folder.
 *                       
 *************************************************************************************************/

namespace Assist_UNA
{
    static class Processing
    {
        /* Private members. */
        private static int optionsInstructions;
        private static int optionsLines;
        private static int optionsPages;
        private static string identifier;
        private static string inputFilePath;
        private static string intermediateFilePath;
        private static string objectFilePath;
        private static string prtFilePath;
        private static string sourceFileDirectory;
        private static string sourceFileName;
        private static string sourceFilePath;


        /* Public methods. */

        /******************************************************************************************
         * 
         * Name:        Assemble        
         * 
         * Author(s):   Travis Hunt
         *              
         *              
         * Input:       The main form.   
         * Return:      N/A
         * Description: This method will handle the duties of choosing the option to only assemble.
         *              
         *****************************************************************************************/
        public static void Assemble(MainForm main)
        {
            Cursor.Current = Cursors.AppStarting;

            identifier = "";
            inputFilePath = "";

            sourceFileDirectory = main.GetDirectory();
            sourceFileName = main.GetFileNameProject();
            
            sourceFilePath = String.Format(@"{0}\{1}.una", sourceFileDirectory, sourceFileName);
            intermediateFilePath = String.Format(@"{0}\{1}.imf", sourceFileDirectory, sourceFileName);
            objectFilePath = String.Format(@"{0}\{1}.obj", sourceFileDirectory, sourceFileName);
            prtFilePath = main.GetPathPRT();

            optionsInstructions = main.GetMaxInstructions();
            optionsLines = main.GetMaxLines();
            optionsPages = main.GetMaxPages();

            Assembler assembler = new Assembler(identifier, sourceFilePath, prtFilePath,
                                                        intermediateFilePath, objectFilePath,
                                                        optionsInstructions, optionsLines,
                                                        optionsPages);

            assembler.Pass1();
            if (assembler.Pass2() == "IOException")
                main.SetPathPRT(String.Format(@"{0}\{1}.PRT", sourceFileDirectory, sourceFileName));

            Cursor.Current = Cursors.Default;

            MessageBox.Show("Your project has been assembled.");

            File.Delete(objectFilePath);
            File.Delete(intermediateFilePath);
        }

        public static void AssembleDebug(MainForm main)
        {

        }

        public static void AssembleFinalRun(MainForm main)
        {

        }
    }
}
