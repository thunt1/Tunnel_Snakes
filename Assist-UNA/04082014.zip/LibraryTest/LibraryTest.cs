﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LibraryTest;

/**************************************************************************************************
 * 
 * Name: LibraryTest
 * 
 * ================================================================================================
 * 
 * Description: This class represents all available instructions available to the ASSIST/UNA 
 *              assembly language. Interaction with this class should be done through the public
 *              method SimulateInstruction, which will then call the necessary methods to perform
 *              the intended operations as specified in the object code. 
 *                       
 * ================================================================================================        
 * 
 * Modification History
 * --------------------
 * 04/04/2014   CAF     Created class LibraryTest class and created the initial switch statement
 * 04/05/2014   CAF     Created shell functions for each of the methods, added headers for the class
 *                          and each of its methods, assisted in the address calculation methods.
 * 04/05/2014   JMB     Created the address calculation methods, started the test driver.
 * 04/07/2014   JMB     Removed unnecessary uint to int type conversions. Updated DetermineAddressDB
 *                          and DetermineAddressDXB methods. Added Console output for testing.
 *                       
 *************************************************************************************************/

namespace LibraryTest
{
    class LibraryTest
    {
        /* Private members. */
        Memory mainMemory;
        PSW progStatWord;
        Register[] registers;
        

        /* Public methods. */

        /******************************************************************************************
         * 
         * Name:        SimulateInstruction
         * 
         * Author(s):   Chad Farley     
         *              
         * Input:       The locationCounter is an integer, mainMemory is a Memory object.
         * Return:      N/A
         * Description: This method will access in mainMemory at locationCounter to read in the 
         *              appropriate object code to determine which operation is to be performed,
         *              gather all pertinent information according to the object code, and pass
         *              this information to the appropriate method in accordance with the object
         *              code. 
         *              
         *****************************************************************************************/
        public LibraryTest(Memory mainMemoryDriver, Register[] registersDriver, 
            PSW progStatWordDriver)
        {
            mainMemory = mainMemoryDriver;
            registers = registersDriver;
            progStatWord = progStatWordDriver;
        }

        /******************************************************************************************
         * 
         * Name:        SimulateInstruction
         * 
         * Author(s):   Chad Farley
         *                 
         * Input:       The locationCounter is an unsigned integer, andmainMemory is a 
         *                  Memory object.
         * Return:      N/A
         * Description: This method will access in mainMemory at locationCounter to read in the 
         *              appropriate object code to determine which operation is to be performed,
         *              gather all pertinent information according to the object code, and pass
         *              this information to the appropriate method in accordance with the object
         *              code. 
         *              
         *****************************************************************************************/
        //public void SimulateInstruction(out uint locationCounter, out Memory mainMemory)
        //{
        //    switch (mainMemory.GetByteHex(locationCounter))
        //    {
        //        /* A - Add */
        //        case "5A":

        //            break;
        //        /* AP - Add Packed */
        //        case "FA":
        //            break;
        //        /* AR - Add Register */
        //        case "1A":
        //            break;
        //        /* BAL - Branch and Link */
        //        case "45":
        //            break;
        //        /* BALR - Branch and Link Register */
        //        case "05":
        //            break;
        //        /* BC - Branch on Condition */
        //        case "47":
        //            break;
        //        /* BCR - Branch on Condition Register */
        //        case "07":
        //            break;
        //        /* BCT - Branch on Count */
        //        case "46":
        //            break;
        //        /* BCTR - Branch on Count Register */
        //        case "06":
        //            break;
        //        /* BXH - Branch on Index High */
        //        case "86":
        //            break;
        //        /* BXLE - Branch on Index Low or Equal */
        //        case "87":
        //            break;
        //        /* C - Compare */
        //        case "59":
        //            break;
        //        /* CLC - Compare Logical Characters */
        //        case "D5":
        //            break;
        //        /* CLI - Compare Logical Immediate */
        //        case "95":
        //            break;
        //        /* CP - Compare Packed */
        //        case "F9":
        //            break;
        //        /* CR - Compare Register */
        //        case "19":
        //            break;
        //        /* D - Divide */
        //        case "5D":
        //            break;
        //        /* DP - Divide Packed */
        //        case "FD":
        //            break;
        //        /* DR - Divide Register */
        //        case "1D":
        //            break;
        //        /* ED - Edit */
        //        case "DE":
        //            break;
        //        /* EDMK - Edit and Mark */
        //        case "DF":
        //            break;
        //        /* L - Load */
        //        case "58":
        //            break;
        //        /* LA - Load Address */
        //        case "41":
        //            break;
        //        /* LM - Load Multiple */
        //        case "98":
        //            break;
        //        /* LR - Load Register */
        //        case "18":
        //            break;
        //        /* M - Multiply */
        //        case "5C":
        //            break;
        //        /* MP - Multiply Packed */
        //        case "FC":
        //            break;
        //        /* MR - Multiply Register */
        //        case "1C":
        //            break;
        //        /* MVC - Move Characters */
        //        case "D2":
        //            break;
        //        /* MVI - Move Immediate */
        //        case "92":
        //            break;
        //        /* N - Bitwise AND */
        //        case "54":
        //            break;
        //        /* NR - Bitwise AND Register */
        //        case "14":
        //            break;
        //        /* O - Bitwise OR */
        //        case "56":
        //            break;
        //        /* OR - Bitwise OR Register */
        //        case "16":
        //            break;
        //        /* PACK - Pack */
        //        case "F2":
        //            break;
        //        /* S - Subtract */
        //        case "5B":
        //            break;
        //        /* SP - Subtract Packed */
        //        case "FB":
        //            break;
        //        /* SR - Subtract Register */
        //        case "1B":
        //            break;
        //        /* ST - Store */
        //        case "50":
        //            break;
        //        /* STM - Store Multiple */
        //        case "90":
        //            break;
        //        /* UNPK - Unpack */
        //        case "F3":
        //            break;
        //        /* XDECI - Convert Input to Decimal*/
        //        case "53":
        //            break;
        //        /* XDECO - Convert Output to Decimal */
        //        case "52":
        //            break;
        //        /* XPRNT/XREAD */
        //        case "E0":
        //            /* XPRNT - Print Output */
        //            if (mainMemory.GetByteHex(locationCounter + 1) == "20")
        //            {

        //            }
        //            /* XREAD - Read Input */
        //            else if (mainMemory.GetByteHex(locationCounter = 1) == "00")
        //            {

        //            }
        //            /* ERROR */
        //            else
        //            {

        //            }
        //            break;
        //        /* ZAP - Zero, Add Packed */
        //        case "F8":
        //            break;
        //        /* ERROR */
        //        default:
        //            break;
        //    };
        //}


        /* Protected methods. */

        /******************************************************************************************
         * 
         * Name:        DetermineAddressDB
         * 
         * Author(s):   Chad Farley
         *              Michael Beaver
         *              
         * Input:       The addressStart is an unsigned integer.
         * Return:      An integer value that is an index into mainMemory.
         * Description: This method is used to determine what address location in memory is to be
         *                  accessed. This method will add the displacement and the contents of the
         *                  base register to calculate the address in memory.
         *              
         *****************************************************************************************/
        public int DetermineAddressDB(uint addressStart)
        {
            int displacement = 0;
            int index = 0;
            int regNo = 0;
            int regValue = 0;
            string addressParameters;

            addressParameters = mainMemory.GetBytesString(addressStart, addressStart + 1);
            displacement = Convert.ToInt32(addressParameters.Substring(1, 3), 16);
            regNo = Convert.ToInt32(addressParameters[0].ToString(), 16);
            //regValue = Convert.ToInt32(registers[regNo].GetBytesString(0, 3), 16);
            regValue = Convert.ToInt32(registers[regNo].GetBytesString(2, 3).Substring(1, 3), 16);

            index = displacement + regValue;

            Console.WriteLine("Displacement: {0}", displacement.ToString("X"));
            Console.WriteLine("Base Register: {0}", regNo.ToString("X"));
            Console.WriteLine("Base Register Value: {0}", regValue.ToString("X"));

            return index;
        }

        /******************************************************************************************
         * 
         * Name:        DetermineAddressDXB
         * 
         * Author(s):   Chad Farley
         *              Michael Beaver
         *              
         * Input:       The addressStart is an unsigned integer.
         * Return:      An integer value that is an index into mainMemory.
         * Description: This method is used to determine what address location in memory is to be
         *                  accessed. This method will add the displacement and the contents of the
         *                  base register and the index register to calculate the address in memory.  
         *              
         *****************************************************************************************/
        public int DetermineAddressDXB(uint addressStart)
        {
            int displacement = 0;
            int baseRegNo = 0;
            int baseRegValue = 0;
            int index = 0;
            int indexRegNo = 0;
            int indexRegValue = 0;
            string addressParameters;

            addressParameters = mainMemory.GetBytesString(addressStart, addressStart + 2);

            indexRegNo = Convert.ToInt32(addressParameters[1].ToString(), 16);
            baseRegNo = Convert.ToInt32(addressParameters[2].ToString(), 16);

            displacement = Convert.ToInt32(addressParameters.Substring(3, 3), 16);
            //baseRegValue = Convert.ToInt32(registers[baseRegNo].GetBytesString(0, 3), 16);
            //indexRegValue = Convert.ToInt32(registers[indexRegNo].GetBytesString(0, 3), 16);
            baseRegValue = Convert.ToInt32(registers[baseRegNo].
                GetBytesString(2, 3).Substring(1, 3), 16);
            indexRegValue = Convert.ToInt32(registers[indexRegNo].
                GetBytesString(2, 3).Substring(1, 3), 16);

            index = baseRegValue + indexRegValue + displacement;

            Console.WriteLine("Displacement: {0}", displacement.ToString("X"));
            Console.WriteLine("Base Register: {0}", baseRegNo.ToString("X"));
            Console.WriteLine("Base Register Value: {0}", baseRegValue.ToString("X"));
            Console.WriteLine("Index Register: {0}", indexRegNo.ToString("X"));
            Console.WriteLine("Index Register Value: {0}", indexRegValue.ToString("X"));

            return index;
        }      


        /* Private methods. */

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionA(uint locationCounter, int registerIndex, int addressIndex)
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionAP(uint locationCounter, 
            int firstAddressIndex, int secondAddressIndex)
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionAR(uint locationCounter,
            int firstRegisterIndex, int secondRegisterIndex)
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionBAL(uint locationCounter,
            int registerIndex, int addressIndex)
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionBALR(uint locationCounter,
            int firstRegisterIndex, int secondRegisterIndex)
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionBC(uint locationCounter,
            int addressIndex)
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionBCR()
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionBCT()
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionBCTR()
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionBXH()
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionBXLE()
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionC()
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionCLC()
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionCLI()
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionCP()
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionCR()
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionD()
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionDP()
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionDR()
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionED()
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionEDMK()
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionL()
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionLA()
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionLM()
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionLR()
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionM()
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionMP()
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionMR()
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionMVC()
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionMVI()
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionN()
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionNR()
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionO()
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionOR()
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionPACK()
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionS()
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionSP()
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionSR()
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionST()
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionSTM()
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionUNPK()
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionXDECI()
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionXDECO()
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionXPRNT()
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionXREAD()
        {

        }

        /******************************************************************************************
         * 
         * Name:        
         * 
         * Author(s):   
         *              
         *              
         * Input:       
         * Return:      
         * Description: 
         *              
         *              
         *****************************************************************************************/
        private void PerformInstructionZAP()
        {

        }
    }
}
